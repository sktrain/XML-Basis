/*  Erg�nzen Sie das folgende Skript um die Erzeugung 
einer passenden Tabelle mit den Spalten "id" und "val". 
Verwenden Sie das Schema OE.
*/


INSERT INTO XMLTAB
SELECT EXTRACTVALUE(VALUE(p), '/PurchaseOrder/Reference'),
VALUE(p)
FROM oe.purchaseorder p
WHERE EXISTSNODE(OBJECT_VALUE, '/PurchaseOrder[User="SBELL"]') = 1;

/* F�gen Sie  in das gespeicherte XML-Dokument ein neues 
Element "<name>My Name</name>" vor dem Element "/PurchaseOrder/Actions" ein, 
wobei nur die XML-Dokument in Zeilen mit der "id LIKE '%3653%' " betrachtet 
werden sollen.
Verwenden Sie "INSERTXMLBEFORE()" bzw. die entsprechende XQUery-Update-Facility
*/


/* F�gen Sie in obiges XML-Dokument ein neues Kindelement unter
dem Element "/PurchaseOrder/Actions" folgender Form:
"<new_name>Kiran Kumar</new_name>" 
ein. (Es kann "INSERTCHILDXML()" bzw. die entsprechende XQUery-Update-Facility
verwendet werden)
*/

  
/* L�schen Sie das zuletzt hinzugef�gte Element wieder
*/




/*  Update mitttels PL/SQL-Paket

F�hren Sie das folgende Skriptaus, welches die zu verwendende
Tabelle erstellt.
*/
--drops the table if already exits
DROP TABLE PRACTICE;
--Creates the table
CREATE TABLE PRACTICE(
id number,
name varchar2(200),
salary number );

/* 
Erg�nzen Sie das folgende PL/SQL-Programm so, dass ein 
entsprechender Update erfolgt.
*/
DECLARE
  x_input CLOB;
  x_context DBMS_XMLStore.ctxType;
  x_rows NUMBER;
BEGIN
  x_context := DBMS_XMLStore.newContext('PRACTICE');
  DBMS_XMLStore.setRowTag(x_context, 'EMPLOYEE');
  DBMS_XMLStore.setUpdateColumn(x_context, 'ID' );
  DBMS_XMLStore.setUpdateColumn(x_context, 'NAME' );
  DBMS_XMLStore.setUpdateColumn(x_context, 'SALARY' );
  x_input:='<EMPLOYEE><ID>100</ID><NAME>Praveen</NAME><SALARY>1000</SALARY></EMPLOYEE>' ;
  x_rows := DBMS_XMLStore.insertXML(x_context, x_input );
  x_input:='<EMPLOYEE><ID>111</ID><NAME>KIRAN</NAME><SALARY>2000</SALARY></EMPLOYEE>' ;
  x_rows := DBMS_XMLStore.insertXML(x_context, x_input );
  
  -- <TODO>
  
  COMMIT ;
END ;
   / 

/*
L�schen Sie die Tabelle und legen Sie sie wieder neu an.

Erg�nzen Sie das folgende PL/SQL-Programm so, dass ein Update 
mit dem Eintrag vor dem "<todo>" erfolgt.
*/
DECLARE
  x_input CLOB;
  x_context DBMS_XMLStore.ctxType;
  x_rows NUMBER;
BEGIN
  x_context := DBMS_XMLStore.newContext('PRACTICE');
  DBMS_XMLStore.setRowTag(x_context, 'EMPLOYEE');
  DBMS_XMLStore.setKeyColumn(x_context, 'ID' );
  x_input:='<EMPLOYEE><ID>100</ID><NAME>Pramod</NAME><SALARY>2000</SALARY></EMPLOYEE>' ;
  
  --<TODo>
  
  DBMS_XMLStore.closeContext(x_context);
  COMMIT ;
END ;
   /


/* Erg�nzen Sie das folgende PL/SQL-Programm so, dass der 
entsprechende Eintrag (vor dem todo) gel�scht wird.
*/
DECLARE
  x_input CLOB;
  x_context DBMS_XMLStore.ctxType;
  x_rows NUMBER;
BEGIN
  x_context := DBMS_XMLStore.newContext('PRACTICE');
  DBMS_XMLStore.setRowTag(x_context, 'EMPLOYEE');
  DBMS_XMLStore.setKeyColumn(x_context, 'ID' );
  x_input:='<EMPLOYEE><ID>100</ID><NAME>Pramod</NAME><SALARY>2000</SALARY></EMPLOYEE>' ;
  
  --<TODO>
  
  DBMS_XMLStore.closeContext(x_context);
  COMMIT ;
END ;
   /


/* 08_04: Nutzung des DBMS_XMLGEN-Package

F�hren Sie das folgende Skript aus, welches die zu verwendende
Tabelle erzeugt.
*/
--drop table if already exists
DROP TABLE practice_gentab; 
CREATE TABLE practice_gentab(result CLOB);

/*
Erg�nzen Sie den Schritt unter <todo> im PL/SQL-Programm so,
dass das XML erzeugt und anschlie�end eingetragen werden kann.
*/
DECLARE
  qryCtx DBMS_XMLGEN.ctxHandle;
  result CLOB;
BEGIN
  qryCtx := DBMS_XMLGEN.newContext('SELECT * FROM hr.employees');
  -- Set the row header to be EMPLOYEE
  DBMS_XMLGEN.setRowTag(qryCtx, 'EMPLOYEE');
  -- Get the result
  
  -- <TODO>
  
  INSERT INTO practice_gentab VALUES
    (result
    );
  --Close context
  DBMS_XMLGEN.closeContext(qryCtx);
END;
/
