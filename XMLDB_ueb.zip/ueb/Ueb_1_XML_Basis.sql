
/* Erkl�ren Sie folgende Begriffe im Bezug auf ein XML-Dokument */
  Element
  Attribute
  Entity 
  CDATA
  
/* Identifizieren Sie im folgenden XML-Dokument:
  Processing instruction
  Element
  Attribute
  Entity 
  CDATA
  XML Document
*/
<?xml version="1.0" encoding="WINDOWS-1252"?>
 <employees>
   <employee id="100">
   <name>Rachael O&apos;Leary</name>
   </employee>
 </employees>

/* Was ist ein XML-Namensraum und wozu braucht man diesen*/


/* Was ist ein XML Schema? */


/* Erl�utern Sie im folgenden Schema die Bedeutuung der folgenden Zeilen
  xmlns:xsd=http://www.w3.org/2001/XMLSchema
  targetNamespace=http://www.books.org
  xmlns=http://www.books.org
  elementFormDefault="qualified">
*/
-- XML schema
<?xml version="1.0"?>
<xsd:schema xmlns:xsd="http://www.w3.org/2001/XMLSchema"                     
targetNamespace="http://www.books.org"
xmlns="http://www.books.org"
elementFormDefault="qualified">
    <xsd:element name="BookStore">
        <xsd:complexType>
            <xsd:sequence>
<xsd:element ref="Book" minOccurs="1"
  maxOccurs="unbounded"/>
            </xsd:sequence>
        </xsd:complexType>
    </xsd:element>
    <xsd:element name="Book">
        <xsd:complexType>
            <xsd:sequence>
                <xsd:element ref="Title" minOccurs="1"  maxOccurs="1"/>
                <xsd:element ref="Author" minOccurs="1"  maxOccurs="1"/>
  <xsd:element ref="Date" minOccurs="1"   maxOccurs="1"/>
                <xsd:element ref="ISBN" minOccurs="1"   maxOccurs="1"/>
                <xsd:element ref="Publisher" minOccurs="1"   maxOccurs="1"/>
            </xsd:sequence>
        </xsd:complexType>
    </xsd:element>
    <xsd:element name="Title" type="xsd:string"/>
    <xsd:element name="Author" type="xsd:string"/>
    <xsd:element name="Date" type="xsd:string"/>
    <xsd:element name="ISBN" type="xsd:string"/>
    <xsd:element name="Publisher" type="xsd:string"/>
</xsd:schema>


/* Was sind typische Attribute eines <element>-Tags in einer Schema-Datei? */


/* Was ist ein komplexer Typ und welche Content-Modelle kann er haben? 
   Was sollte im folgenden XML-Dokument* durch einen komplexen Typ in
   einem entsprechenden Schema definiert werden? 
*/	
<?xml version="1.0"?>
<region xmlns:xsi="http://...">
<region_id>1</region_id>
<region_name>Europe</region_name>
</region>