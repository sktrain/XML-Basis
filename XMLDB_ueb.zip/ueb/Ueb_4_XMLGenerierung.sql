/*******************************/
/* Aufgaben mit Kurs-Datenbank */
/*******************************/


/* Generieren Sie die Kursdaten in folgendem XML-Format 
 * (bestehend aus Titel und Untertitel)
 * <Titel>Perl Module programmieren in Perl</Titel>
  <Titel>Perl Programmierung von GUIs mit Perl/Tk</Titel>
  <Titel>Perl Netzwerkprogrammierung</Titel>
  ....
  */



  
/* Generieren Sie die Kursdaten in folgendem Format:
<Name>
  <Titel>Perl</Titel>
  <Untertitel>Module programmieren in Perl</Untertitel>
</Name>
...
*/




/* Generieren Sie die Kursdaten in folgendem Format:

<Kurs Nummer="1025039">
  <Bereich>Datenbanken</Bereich>
  <Name>
    <Titel>SQL</Titel>
    <Untertitel>DDL, DML + DCL</Untertitel>
  </Name>
  <Dauer>2</Dauer>
  <Anforderungen>
    <Zielgruppe>DB-Administratoren, DB-Entwickler</Zielgruppe>
    <Vorkenntnisse>Grundlagen in Windows</Vorkenntnisse>
  </Anforderungen>
  <Kosten>
    <Preis Typ="TN1" W�hrung="Euro">870</Preis>
    <Preis Typ="TN2" W�hrung="Euro">827</Preis>
    <Preis Typ="TN3" W�hrung="Euro">786</Preis>
    <Preis Typ="TN4" W�hrung="Euro">747</Preis>
    <Preis Typ="TN5" W�hrung="Euro">710</Preis>
  </Kosten>
  <Inhalt>A. Einf�hrung B. Datenbank und Tabellen anlegen und �ndern C. 
  Daten einf�gen und �ndern D. Grundstrukturen einfacher Abfragen E. 
  Komplexe Abfragen, Unterabfragen und Funktionen F. 
  Abfragen in virtuellen Tabellen speichern G. 
  Zugriffskontrolle durch Benutzer, Rechte und Rollen H. 
  MS SQL Server und Transact SQL I. Oracle und PL/SQL</Inhalt>
</Kurs>

*/




/* Generieren Sie die Teilnehmerdaten unter Verwendung von XMLForest() f�r 
 * TN_Nr 5 in folgendem Format:

<Teilnehmer Nr="5">
  <Name Anrede="Herr">
    <Vorname>Norbert</Vorname>
    <Nachname>Fahle</Nachname>
  </Name>
  <Adresse>
    <Stra�e>Steeler Str.</Stra�e>
    <Hausnr>43</Hausnr>
    <PLZ>44866</PLZ>
    <Stadt>Bochum</Stadt>
    <Stadtteil>Wattenscheid</Stadtteil>
    <Telnr>2327-598187</Telnr>
  </Adresse>
</Teilnehmer>
<Unternehmen Nr="126">
  <Name>Abfallentsorgungs- und Altlastensanierungsverband Rhein-Ruhr</Name>
  <Branche>Recycling</Branche>
  <Adresse>
    <Stra�e>Werksstr.</Stra�e>
    <Hausnr>15</Hausnr>
    <PLZ>45527</PLZ>
    <Stadt>Hattingen, Ruhr</Stadt>
    <Stadtteil>Welper</Stadtteil>
    <Telnr>2324-5094</Telnr>
  </Adresse>
</Unternehmen>

*/

  


/* Generieren Sie die Kursdaten in folgendem Format:

<?xml version="1.0" standalone="yes"?>
<Name>
  <Titel>Oracle</Titel>
  <Untertitel>PL/SQL-Programmierung</Untertitel>
</Name>

*/



/* Generieren Sie die Kursdaten in folgendem Format:

<?xml version="1.0" standalone="yes"?>
<?xml-stylesheet type="text/css" href="test.css"?>
<Name>
  <Titel>Oracle</Titel>
  <Untertitel>PL/SQL-Programmierung</Untertitel>
</Name>

*/  



/* Generieren Sie die Kurstermine unter Verwendung von XMLConcat()
 * in folgendem Format

<Kurs>1020053</Kurs>
<Ort>Bochum</Ort>
<Beginn>18.02.00</Beginn>
<Ende>20.02.00</Ende>

*/

 
 
 
 
 
/* Generieren Sie die Kurstermine unter Verwendung von XMLColAttVal()
 * in folgendem Format

<Kurs>
  <column name="K_TITEL">Oracle PL/SQL-Programmierung</column>
  <column name="K_DAUER">3</column>
</Kurs>

*/

 
 

/* Generieren Sie die Kursdaten unter Verwendung von XMLagg() nur f�r
 * die Titel "Java" und "Oracle" in folgendem Format:
 
<Kurs Titel="Java">
  <Untertitel>Kochrezepte</Untertitel>
  <Untertitel>Enterprise Java Beans</Untertitel>
  <Untertitel>Servlets</Untertitel>
  <Untertitel>Syntax + Konzepte</Untertitel>
  <Untertitel>Designpatterns</Untertitel>
  <Untertitel>Netzwerke + Sockets</Untertitel>
  <Untertitel>Java Server Pages (JSP)</Untertitel>
  <Untertitel>Datenbankprogrammierung</Untertitel>
  <Untertitel>Java f�r Oracle</Untertitel>
</Kurs>

*/

 
 
/* Generieren Sie die Kursdaten unter Verwendung von XMLagg() und 
 * XMLForest() nur f�r die Titel "Java" und "Oracle" in folgendem Format:

<Kurs Nr="1015036">
  <Titel>Java Servlets</Titel>
  <Termine>
    <Termin Nr="422">
      <Beginn>2003-04-01</Beginn>
      <Ende>2003-04-03</Ende>
      <Ort>Bochum</Ort>
    </Termin>
    <Termin Nr="463">
      <Beginn>2003-05-05</Beginn>
      <Ende>2003-05-07</Ende>
      <Ort>Dortmund</Ort>
    </Termin>
    <Termin Nr="510">
      <Beginn>2003-06-23</Beginn>
      <Ende>2003-06-24</Ende>
      <Ort>Bochum</Ort>
    </Termin>
    <Termin Nr="511">
      <Beginn>2003-06-23</Beginn>
      <Ende>2003-06-24</Ende>
      <Ort>Dortmund</Ort>
    </Termin>
    <Termin Nr="1">
      <Beginn>2000-02-18</Beginn>
      <Ende>2000-02-20</Ende>
      <Ort>Bochum</Ort>
    </Termin>
    <Termin Nr="3">
      <Beginn>2000-02-18</Beginn>
      <Ende>2000-02-20</Ende>
      <Ort>Bochum</Ort>
    </Termin>
    <Termin Nr="54">
      <Beginn>2000-05-13</Beginn>
      <Ende>2000-05-15</Ende>
      <Ort>Bochum</Ort>
    </Termin>
    <Termin Nr="143">
      <Beginn>2001-02-18</Beginn>
      <Ende>2001-02-20</Ende>
      <Ort>Bochum</Ort>
    </Termin>
    <Termin Nr="214">
      <Beginn>2002-02-18</Beginn>
      <Ende>2002-02-20</Ende>
      <Ort>Bochum</Ort>
    </Termin>
    <Termin Nr="216">
      <Beginn>2002-02-18</Beginn>
      <Ende>2002-02-20</Ende>
      <Ort>Bochum</Ort>
    </Termin>
    <Termin Nr="384">
      <Beginn>2003-02-18</Beginn>
      <Ende>2003-02-20</Ende>
      <Ort>Bochum</Ort>
    </Termin>
  </Termine>
</Kurs>

*/



/* Generieren Sie die Kursdaten unter Verwendung von Sys_XMLGen() 
*  f�r die Titel "Java" und "Oracle" in folgendem Format:  

<K_NR>1015024</K_NR>
<K_TITEL>PHP</K_TITEL>
<K_UNTERTITEL>Syntax + Konzepte</K_UNTERTITEL>

<K_NR>1015043</K_NR>
<K_TITEL>PHP</K_TITEL>
<K_UNTERTITEL>Webanwendungen</K_UNTERTITEL>

...

*/



 
/* Generieren Sie die Kursdaten unter Verwendung von Sys_XMLGen() und
 * Sys_XMLAgg() f�r die Titel "Java" und "Oracle" in folgendem Format:  

<ROWSET>
  <K_NR>1015024</K_NR>
  <K_NR>1015043</K_NR>
  <K_NR>1015044</K_NR>
  <K_NR>1015068</K_NR>
</ROWSET>

*/
