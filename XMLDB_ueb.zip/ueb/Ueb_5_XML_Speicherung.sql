/*
Schema-basierte Speicherung mit CLOB
*/
-- Registrierung eines Schemas, das dann benutzt wird

--delete schema if already exits
BEGIN
DBMS_XMLSCHEMA.deleteSchema(
SCHEMAURL => 'http://www.oracle.com/DVDMovies.xsd',
DELETE_OPTION => dbms_xmlschema.DELETE_CASCADE_FORCE);
END;
/
--registers the schema
BEGIN
DBMS_XMLSCHEMA.registerSchema('http://www.oracle.com/DVDMovies.xsd',
 '<schema xmlns="http://www.w3.org/2001/XMLSchema"
 targetNamespace="http://www.oracle.com/DVDMovies.xsd" version="1.0"
 xmlns:xdb="http://xmlns.oracle.com/xdb"
 elementFormDefault="qualified">
 <element name = "DVD">
 <complexType>
 <sequence>
 <element name = "DVDId" type = "positiveInteger"/>
 <element name = "Name" type = "string"/> 
 <element name = "Prod_Date" type = "date"/>
 <element name = "Price" type = "positiveInteger"/>
 <element name = "Taxes" type = "positiveInteger"/>
 <element name = "Category">
 <complexType>
 <sequence>
 <element name = "CatNo" type = "positiveInteger" />
 <element name = "CatName" type = "string"/>
 <element name = "Prod" type = "positiveInteger"/>
 </sequence>
 </complexType>
 </element>
 </sequence>
 </complexType>
 </element>
 </schema>',
 TRUE,
 TRUE,
 FALSE);
 END;
/


/*
Erstellen Sie eine Tabelle DVD_Tab auf Basis des Schemas 
mit Speicherunsformat CLOB
*/



/*
Erg�nzen Sie dasa folgende Schema so, dass bei objekt-relationaler Zerlegung
-  ToDo1: <element name="Details"> als CLOB gespeichert wird
-  ToDo2: <element name="City" type="string"/> hinzugef�gt wird
*/
DECLARE
doc VARCHAR2(4000) :=
'<schema xmlns="http://www.w3.org/2001/XMLSchema"
targetNamespace="http://www.oracle.com/Books.xsd"
xmlns:emp="http://www.oracle.com/Books.xsd"
xmlns:xdb="http://xmlns.oracle.com/xdb">
<complexType name="Book" xdb:SQLType="OBJ_T">
<sequence>
<element name="Title" type="string"/>
<element name="Price" type="float"/>

  <TODO1>
  
<complexType >
<sequence>
<element name="Author_Name" type="string"/>
<element name="Phone" type="string"/>
<element name="email" type="string"/>
    <TODO2>
</sequence>
</complexType>
</element>
</sequence>
</complexType>
</schema>';
BEGIN
DBMS_XMLSCHEMA.registerSchema('http://www.oracle.com/Books.xsd',
doc);
END;
/




/*
Erg�nzen Sie foilgendes Schema so, dass bei objekt-relationaler Speicherung der
Default-Table "DET_TAB" genannt wird und 
das Element <Details ...> nicht inline gespeichert wird.
*/
--deletes schema if already exits
BEGIN
DBMS_XMLSCHEMA.deleteSchema(
SCHEMAURL => 'library.xsd',
DELETE_OPTION => dbms_xmlschema.DELETE_CASCADE_FORCE);
END;
/
--registers the schema
DECLARE
 doc VARCHAR2(3000) :=
 '<schema xmlns="http://www.w3.org/2001/XMLSchema"
 targetNamespace="http://www.oracle.com/library.xsd"
 xmlns:BO="http://www.oracle.com/library.xsd"
 xmlns:xdb="http://xmlns.oracle.com/xdb">
 <complexType name="BookType" xdb:SQLType="BO_T">
 <sequence>
 <element name="Title" type="string"/>
 <element name="Details"
 <TODO>
 xdb:defaultTable="DET_TAB">
 <complexType xdb:SQLType="DET_T">
 <sequence>
 <element name="Publication" type="string"/>
 <element name="Author" type="string"/>
 </sequence>
 </complexType>
 </element>
 </sequence>
 </complexType>
 <element name="Book" type="BO:BookType"
 xdb:defaultTable="BO_TAB"/>
 </schema>';
 BEGIN
 DBMS_XMLSCHEMA.registerSchema('library.xsd', doc);
 END;
 /