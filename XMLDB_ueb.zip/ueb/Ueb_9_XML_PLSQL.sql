/*  010_01    Nutzung des DOM-API (DBMS_XMLDOM-Package)

F�hren Sie das Skript in lab_10_01_01.sql aus, um die zu verwendende
Tabelle samt Inhalt zu erzeugen.

Erg�nzen sie das PL/SQL-Programm in lab_10_01_02.txt zu einem lauff�higen 
PL/SQL-Programm.

Erg�nzen Sie das PL/SQL-Programm in lab_10_01_03.txt zu einem lauff�higen
PL/SQL-Programm.

*/

