/* Speichern Sie in einer neuen Tabelle Records aus der Employee-Tabelle,
 * deren employee_id > 200 ist in folgendem Format:
 * 
empid     empname
-------------------------------
201 <Emp>Michael Hartstein</Emp>
202 <Emp>Pat Fay</Emp>
203 <Emp>Susan Mavris</Emp>
204 <Emp>Hermann Baer</Emp>
...
 * Verwenden Sie zum Aufbau der XML-Daten den Konstruktor von XMLType oder
 * die statische Erzeugungsmethode.
 */
 


/* K�nnen Sie das nicht wohlgeformte Element
 * <Murks> hallo
 * unter der id 100 in obige Tabelle einf�gen.
 */


