/* Speichern Sie in einer neuen Tabelle Records aus der Employee-Tabelle,
 * deren employee_id > 200 ist in folgendem Format:
 * 
empid     empname
-------------------------------
201 <Emp>Michael Hartstein</Emp>
202 <Emp>Pat Fay</Emp>
203 <Emp>Susan Mavris</Emp>
204 <Emp>Hermann Baer</Emp>
...
 * Verwenden Sie zum Aufbau der XML-Daten den Konstruktor von XMLType oder
 * die statische Erzeugungsmethode.
 */
 
-- mit Konstruktor 
CREATE TABLE emp_xml_1 AS 
 SELECT employee_id, XMLType(fullname) as xml_data FROM
  (SELECT employee_id, '<Emp>' || first_name || ' ' || last_name || '</Emp>' 
     as fullname   FROM employees where employee_id > 200 );
     
-- mit statischer Erzeugungsmethode
CREATE TABLE emp_xml_1 AS 
 SELECT employee_id, XMLType.CreateXML(fullname) as xml_data FROM
  (SELECT employee_id, '<Emp>' || first_name || ' ' || last_name || '</Emp>' 
     as fullname   FROM employees where employee_id > 200 );
     
SELECT * FROM emp_xml_1;



/* K�nnen Sie das nicht wohlgeformte Element
 * <Murks> hallo
 * unter der id 100 in obige Tabelle einf�gen.
 */
-- Versuch liefert Fehler
INSERT INTO emp_xml_1 VALUES (100, XMLTYPE('<Murks> hallo', wellformed => 1));

-- Wir k�nnen zwar solches XML erzeugen, aber nicht speichern
SELECT XMLTYPE('<Murks> hallo', wellformed => 1)  res FROM dual;
 
 -- Aufr�umen
DROP TABLE emp_xml_1;

