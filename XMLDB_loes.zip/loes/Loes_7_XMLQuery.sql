/* Bei dem Zugriff auf den XML-Content k�nnen Sie erstmal  
"fn:collection" verwenden, um den Content f�r die Xquery-Ausdr�cke 
zur Verf�gung zu stellen.
*/


/* Geben Sie den Inhalt der Tabelle HR.EMPLOYEES wie folgt aus:

<FIRST_NAME>Alexander</FIRST_NAME>
<FIRST_NAME>Bruce</FIRST_NAME>
...

Dabei sollen nur die Mitarbeitervornamen ausgegeben werden, deren 
Gehalt > 5000 ist und die in Abteilung mit der ID 60 (department_id) sind.
*/
SELECT XMLQuery(
     'for $i in fn:collection("oradb:/HR/EMPLOYEES")
      where $i/ROW/DEPARTMENT_ID = 60 and  $i/ROW/SALARY > 5000
      return $i/ROW/FIRST_NAME' returning content) AS HR
 FROM dual;
 
 
/* Geben Sie den Inhalt der Tabelle HR.EMPLOYEES wie folgt aus:

<EMPLOYEE NAME="Michael"><MANAGER>Steven</MANAGER></EMPLOYEE>
<EMPLOYEE NAME="Pat"><MANAGER>Michael</MANAGER></EMPLOYEE>
...

Dabei sollen nur Mitarbeiter in der Abteilung 20 betrachtet werden.
Die Ausgabe besteht auds den Mitarbeitervornamen und dem Vornamen des 
jeweiligen Chefs (referenziert via manager_id) ausgegeben werden. 
(Es soll nat�rlich mit XQuery der "JOIN" ausgef�hrt werden)
*/
SELECT XMLQUERY('
  for $i in fn:collection("oradb:/HR/EMPLOYEES")/ROW
    where $i/DEPARTMENT_ID = 20
  return <EMPLOYEE NAME ="{ $i/FIRST_NAME  }">
     {
       for $j in fn:collection("oradb:/HR/EMPLOYEES")/ROW
        where $j/EMPLOYEE_ID eq $i/MANAGER_ID
       return <MANAGER>{$j/FIRST_NAME/text()} </MANAGER>
     }
  </EMPLOYEE>'
 returning content) as res FROM dual;


/* Komplettieren Sie den folgenden Code. (<TODO>)

SELECT lines.lineitem, lines.description, lines.partid,lines.unitprice, lines.quantity 
FROM purchaseorder, XMLTable('
	for $i in /PurchaseOrder/LineItems/LineItem 
	return $i' 
	PASSING OBJECT_VALUE
	COLUMNS
		lineitem NUMBER PATH   @ItemNumber
		description       <TODO>,
		partid            <TODO>,
		unitprice         <TODO> 
		quantity          <TODO>
    )  lines;

Der Code kann im Schema OE ausgef�hrt werden.
*/
SELECT lines.lineitem, lines.description, lines.partid, lines.unitprice, lines.quantity 
FROM purchaseorder, XMLTable('
	for $i in /PurchaseOrder/LineItems/LineItem 
	return $i' 
	PASSING OBJECT_VALUE
	COLUMNS
		lineitem NUMBER PATH '@ItemNumber',
		description VARCHAR2(30) PATH 'Description',
		partid NUMBER PATH 'Part/@Id',
		unitprice NUMBER PATH 'Part/@UnitPrice', 
		quantity NUMBER PATH 'Part/@Quantity') lines;

/* Modifizieren Sie die vorherige L�sung so, dass nur die Records
ausgegeben werden, f�r die gleichzeitig gilt:
"ItemNumber" >= 8 
"UnitPrice" > 50 
"Quantity" > 2 
*/
SELECT lines.lineitem, lines.description, lines.partid, lines.unitprice, lines.quantity 
FROM purchaseorder, XMLTable('
	for $i in /PurchaseOrder/LineItems/LineItem
    where $i/@ItemNumber >= 8 
      and $i/Part/@UnitPrice > 50 
      and $i/Part/@Quantity > 2 
	return $i' 
	PASSING OBJECT_VALUE
	COLUMNS
		lineitem NUMBER PATH '@ItemNumber',
		description VARCHAR2(30) PATH 'Description',
		partid NUMBER PATH 'Part/@Id',
		unitprice NUMBER PATH 'Part/@UnitPrice', 
		quantity NUMBER PATH 'Part/@Quantity') lines;

