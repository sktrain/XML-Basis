/*******************************/
/* Aufgaben mit Kurs-Datenbank */
/*******************************/


/* Generieren Sie die Kursdaten in folgendem XML-Format 
 * (bestehend aus Titel und Untertitel)
 * <Titel>Perl Module programmieren in Perl</Titel>
  <Titel>Perl Programmierung von GUIs mit Perl/Tk</Titel>
  <Titel>Perl Netzwerkprogrammierung</Titel>
  ....
  */

SELECT XMLElement("Titel", K_Titel || ' ' || K_Untertitel) as res
  FROM kurs;
  
/* Generieren Sie die Kursdaten in folgendem Format:
<Name>
  <Titel>Perl</Titel>
  <Untertitel>Module programmieren in Perl</Untertitel>
</Name>
...
*/
SELECT XMLElement("Name",
        XMLElement("Titel", K_Titel),
        XMLElement("Untertitel", K_Untertitel))  AS res
  FROM kurs;


/* Generieren Sie die Kursdaten in folgendem Format:
<Kurs Nummer="1025039">
  <Bereich>Datenbanken</Bereich>
  <Name>
    <Titel>SQL</Titel>
    <Untertitel>DDL, DML + DCL</Untertitel>
  </Name>
  <Dauer>2</Dauer>
  <Anforderungen>
    <Zielgruppe>DB-Administratoren, DB-Entwickler</Zielgruppe>
    <Vorkenntnisse>Grundlagen in Windows</Vorkenntnisse>
  </Anforderungen>
  <Kosten>
    <Preis Typ="TN1" W�hrung="Euro">870</Preis>
    <Preis Typ="TN2" W�hrung="Euro">827</Preis>
    <Preis Typ="TN3" W�hrung="Euro">786</Preis>
    <Preis Typ="TN4" W�hrung="Euro">747</Preis>
    <Preis Typ="TN5" W�hrung="Euro">710</Preis>
  </Kosten>
  <Inhalt>A. Einf�hrung B. Datenbank und Tabellen anlegen und �ndern C. 
  Daten einf�gen und �ndern D. Grundstrukturen einfacher Abfragen E. 
  Komplexe Abfragen, Unterabfragen und Funktionen F. 
  Abfragen in virtuellen Tabellen speichern G. 
  Zugriffskontrolle durch Benutzer, Rechte und Rollen H. 
  MS SQL Server und Transact SQL I. Oracle und PL/SQL</Inhalt>
</Kurs>
*/
SELECT XMLElement("Kurs", XMLAttributes(K_Nr AS "Nummer"),
       XMLElement("Bereich", K_Bereich),
       XMLElement("Name",
        XMLElement("Titel", K_Titel),
        XMLElement("Untertitel", K_Untertitel)),
       XMLElement("Dauer", K_Dauer),
       XMLElement("Anforderungen",
        XMLElement("Zielgruppe", K_Zielgruppe),
        XMLElement("Vorkenntnisse", K_Vorkenntnisse)),
       XMLElement("Kosten",
        XMLElement("Preis", XMLAttributes('TN1'  AS "Typ",
                                          'Euro' AS "W�hrung"), P_TN1),
        XMLElement("Preis", XMLAttributes('TN2'  AS "Typ",
                                          'Euro' AS "W�hrung"), P_TN2),
        XMLElement("Preis", XMLAttributes('TN3'  AS "Typ",
                                          'Euro' AS "W�hrung"), P_TN3),
        XMLElement("Preis", XMLAttributes('TN4'  AS "Typ",
                                          'Euro' AS "W�hrung"), P_TN4),
        XMLElement("Preis", XMLAttributes('TN5'  AS "Typ",
                                          'Euro' AS "W�hrung"), P_TN5)), 
       XMLElement("Inhalt", K_Themen)) AS res
  FROM kurs NATURAL JOIN preis
 -- WHERE K_Nr = 1025039
 ;


/* Generieren Sie die Teilnehmerdaten unter Verwendung von XMLForest() f�r 
 * TN_Nr 5 in folgendem Format:

<Teilnehmer Nr="5">
  <Name Anrede="Herr">
    <Vorname>Norbert</Vorname>
    <Nachname>Fahle</Nachname>
  </Name>
  <Adresse>
    <Stra�e>Steeler Str.</Stra�e>
    <Hausnr>43</Hausnr>
    <PLZ>44866</PLZ>
    <Stadt>Bochum</Stadt>
    <Stadtteil>Wattenscheid</Stadtteil>
    <Telnr>2327-598187</Telnr>
  </Adresse>
</Teilnehmer>
<Unternehmen Nr="126">
  <Name>Abfallentsorgungs- und Altlastensanierungsverband Rhein-Ruhr</Name>
  <Branche>Recycling</Branche>
  <Adresse>
    <Stra�e>Werksstr.</Stra�e>
    <Hausnr>15</Hausnr>
    <PLZ>45527</PLZ>
    <Stadt>Hattingen, Ruhr</Stadt>
    <Stadtteil>Welper</Stadtteil>
    <Telnr>2324-5094</Telnr>
  </Adresse>
</Unternehmen>

*/
SELECT XMLElement("Teilnehmer", XMLAttributes(TN_Nr AS "Nr"),
        XMLElement("Name", XMLAttributes(TN_Anrede AS "Anrede"),
         XMLForest(TN_Vorname AS "Vorname",
                   TN_Nachname AS "Nachname")),
       XMLElement("Adresse",
        XMLForest(TN_Strasse AS "Stra�e",
                  TN_Hausnr AS "Hausnr",
                  TN_PLZ AS "PLZ",
                  TN_Stadt AS "Stadt",
                  TN_Stadtteil AS "Stadtteil",
                  TN_Vorwahl||'-'||TN_Telnr AS "Telnr"))),
       XMLElement("Unternehmen", XMLAttributes(U_Nr AS "Nr"),
       XMLElement("Name", U_Name),
       XMLElement("Branche", U_Branche),
       XMLElement("Adresse",
        XMLForest(U_Strasse AS "Stra�e",
                  U_Hausnr AS "Hausnr",
                  U_PLZ AS "PLZ",
                  U_Stadt AS "Stadt",
                  U_Stadtteil AS "Stadtteil",
                  U_Vorwahl||'-'||U_Telnr AS "Telnr"))) AS res
  FROM teilnehmer  NATURAL JOIN unternehmen WHERE TN_Nr =5;
  


/* Generieren Sie die Kursdaten in folgendem Format:

<?xml version="1.0" standalone="yes"?>
<Name>
  <Titel>Oracle</Titel>
  <Untertitel>PL/SQL-Programmierung</Untertitel>
</Name>

*/
SELECT XMLROOT (XMLElement("Name",
        XMLForest(K_Titel AS "Titel",
                  K_Untertitel AS "Untertitel")), 
                    VERSION '1.0', STANDALONE YES)  AS res
  FROM kurs;
  

/* Generieren Sie die Kursdaten in folgendem Format:

<?xml version="1.0" standalone="yes"?>
<?xml-stylesheet type="text/css" href="test.css"?>
<Name>
  <Titel>Oracle</Titel>
  <Untertitel>PL/SQL-Programmierung</Untertitel>
</Name>

*/  
SELECT XMLROOT(
        XMLConcat(XMLPI(NAME "xml-stylesheet", 
                        'type="text/css" href="test.css"'),
          XMLElement("Name",
           XMLForest(K_Titel AS "Titel",
                     K_Untertitel AS "Untertitel"))), 
                     VERSION '1.0', STANDALONE YES)  AS XML
  FROM kurs
WHERE K_Nr = 1025063;


/* Generieren Sie die Kurstermine unter Verwendung von XMLConcat()
 * in folgendem Format

<Kurs>1020053</Kurs>
<Ort>Bochum</Ort>
<Beginn>18.02.00</Beginn>
<Ende>20.02.00</Ende>

*/
SELECT XMLConcat(
       xmltype('<Kurs>'||K_Nr||'</Kurs>'),
       xmltype('<Ort>'||T_Ort||'</Ort>'),
       xmltype('<Beginn>'||T_Beginn||'</Beginn>'),
       xmltype('<Ende>'||T_Ende||'</Ende>')) AS res
  FROM termin
 WHERE T_Nr BETWEEN 2 AND 5;
 
 
 
 
 
/* Generieren Sie die Kurstermine unter Verwendung von XMLColAttVal()
 * in folgendem Format

<Kurs>
  <column name="K_TITEL">Oracle PL/SQL-Programmierung</column>
  <column name="K_DAUER">3</column>
</Kurs>

*/
SELECT XMLELEMENT("Kurs", 
       XMLCOLATTVAL(K_Titel || ' ' || K_Untertitel AS K_TITEL,
                    K_Dauer)) AS XML
  FROM kurs
 WHERE K_Nr = 1025063;
 
 

/* Generieren Sie die Kursdaten unter Verwendung von XMLagg() nur f�r
 * die Titel "Java" und "Oracle" in folgendem Format:
 
<Kurs Titel="Java">
  <Untertitel>Kochrezepte</Untertitel>
  <Untertitel>Enterprise Java Beans</Untertitel>
  <Untertitel>Servlets</Untertitel>
  <Untertitel>Syntax + Konzepte</Untertitel>
  <Untertitel>Designpatterns</Untertitel>
  <Untertitel>Netzwerke + Sockets</Untertitel>
  <Untertitel>Java Server Pages (JSP)</Untertitel>
  <Untertitel>Datenbankprogrammierung</Untertitel>
  <Untertitel>Java f�r Oracle</Untertitel>
</Kurs>

*/
SELECT XMLELEMENT("Kurs", XMLATTRIBUTES(K_Titel AS "Titel"),
       XMLAGG(XMLELEMENT("Untertitel", K_Untertitel)))
       AS XML
 FROM kurs
WHERE K_Titel IN ('Oracle', 'Java')
 GROUP BY K_Titel;
 
 
/* Generieren Sie die Kursdaten unter Verwendung von XMLagg() und 
 * XMLForest() nur f�r die Titel "Java" und "Oracle" in folgendem Format:

<Kurs Nr="1015036">
  <Titel>Java Servlets</Titel>
  <Termine>
    <Termin Nr="422">
      <Beginn>2003-04-01</Beginn>
      <Ende>2003-04-03</Ende>
      <Ort>Bochum</Ort>
    </Termin>
    <Termin Nr="463">
      <Beginn>2003-05-05</Beginn>
      <Ende>2003-05-07</Ende>
      <Ort>Dortmund</Ort>
    </Termin>
    <Termin Nr="510">
      <Beginn>2003-06-23</Beginn>
      <Ende>2003-06-24</Ende>
      <Ort>Bochum</Ort>
    </Termin>
    <Termin Nr="511">
      <Beginn>2003-06-23</Beginn>
      <Ende>2003-06-24</Ende>
      <Ort>Dortmund</Ort>
    </Termin>
    <Termin Nr="1">
      <Beginn>2000-02-18</Beginn>
      <Ende>2000-02-20</Ende>
      <Ort>Bochum</Ort>
    </Termin>
    <Termin Nr="3">
      <Beginn>2000-02-18</Beginn>
      <Ende>2000-02-20</Ende>
      <Ort>Bochum</Ort>
    </Termin>
    <Termin Nr="54">
      <Beginn>2000-05-13</Beginn>
      <Ende>2000-05-15</Ende>
      <Ort>Bochum</Ort>
    </Termin>
    <Termin Nr="143">
      <Beginn>2001-02-18</Beginn>
      <Ende>2001-02-20</Ende>
      <Ort>Bochum</Ort>
    </Termin>
    <Termin Nr="214">
      <Beginn>2002-02-18</Beginn>
      <Ende>2002-02-20</Ende>
      <Ort>Bochum</Ort>
    </Termin>
    <Termin Nr="216">
      <Beginn>2002-02-18</Beginn>
      <Ende>2002-02-20</Ende>
      <Ort>Bochum</Ort>
    </Termin>
    <Termin Nr="384">
      <Beginn>2003-02-18</Beginn>
      <Ende>2003-02-20</Ende>
      <Ort>Bochum</Ort>
    </Termin>
  </Termine>
</Kurs>

*/
SELECT XMLELEMENT("Kurs", XMLATTRIBUTES(kurs.K_Nr AS "Nr"),
         XMLELEMENT("Titel", K_Titel || ' ' || K_Untertitel),
           XMLELEMENT ("Termine",
            (SELECT XMLAGG(XMLELEMENT("Termin", XMLATTRIBUTES(b.T_Nr AS
                                                "Nr"),
               XMLFOREST(T_Beginn AS "Beginn",
                         T_Ende   AS "Ende",
                         T_Ort    AS "Ort")))
           FROM termin b
          WHERE b.K_Nr = a.K_Nr ))) AS XML
  FROM kurs INNER JOIN termin a
    ON kurs.K_Nr = a.K_Nr
 WHERE K_Titel IN ('Oracle', 'Java')
   AND T_Beginn < '31.12.2002';
   


/* Generieren Sie die Kursdaten unter Verwendung von Sys_XMLGen() 
*  f�r die Titel "Java" und "Oracle" in folgendem Format:  

<K_NR>1015024</K_NR>
<K_TITEL>PHP</K_TITEL>
<K_UNTERTITEL>Syntax + Konzepte</K_UNTERTITEL>

<K_NR>1015043</K_NR>
<K_TITEL>PHP</K_TITEL>
<K_UNTERTITEL>Webanwendungen</K_UNTERTITEL>

...

*/
SELECT SYS_XMLGEN(K_Nr) AS Nr,
       SYS_XMLGEN(K_Titel) AS Titel,
       SYS_XMLGEN(K_Untertitel) AS Untertitel
  FROM kurs
 WHERE K_Titel IN ('Oracle', 'Java');


 
/* Generieren Sie die Kursdaten unter Verwendung von Sys_XMLGen() und
 * Sys_XMLAgg() f�r die Titel "Java" und "Oracle" in folgendem Format:  

<ROWSET>
  <K_NR>1015024</K_NR>
  <K_NR>1015043</K_NR>
  <K_NR>1015044</K_NR>
  <K_NR>1015068</K_NR>
</ROWSET>

*/
SELECT SYS_XMLAGG(SYS_XMLGEN(K_Nr)) AS XML
  FROM kurs
 WHERE K_Titel IN ('Oracle', 'Java');