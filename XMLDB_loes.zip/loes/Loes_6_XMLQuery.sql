/* Bei dem Zugriff auf den XML-Content k�nnen Sie erstmal  
"fn:collection" verwenden, um den Content f�r die Xquery-Ausdr�cke 
zur Verf�gung zu stellen.
*/

/* Geben Sie die Inhalte  der Tabelle HR.EMPLOYEES in folgendem 
XML-Format aus:

<EMPLOYEE id="100"><EMPLOYEE_NAME>Steven_K�nig</EMPLOYEE_NAME></EMPLOYEE>
<EMPLOYEE id="101"><EMPLOYEE_NAME>Neena_Kochhar</EMPLOYEE_NAME></EMPLOYEE>
...

Verwenden Sie einmal XMLTABLE und einmal XMLQUERY. 
(Formatierung, d.h. Zeilenumbr�che sind erstmal egal)
*/

-- XMLQuery
Select XMLQuery('
  for $i in fn:collection("oradb:/HR/EMPLOYEES")/ROW
  where $i/EMPLOYEE_ID/text() < 110
  return
    <EMPLOYEE id="{$i/EMPLOYEE_ID}">
      <EMPLOYEE_NAME>
        {$i/FIRST_NAME/text()}_{$i/LAST_NAME/text()}
      </EMPLOYEE_NAME>
    </EMPLOYEE>' Returning content ) as Result FROM Dual;

-- XMLTable
Select * FROM XMLTABLE('
  for $i in fn:collection("oradb:/HR/EMPLOYEES")/ROW
  where $i/EMPLOYEE_ID/text() < 110
  return
    <EMPLOYEE id="{$i/EMPLOYEE_ID}">
      <EMPLOYEE_NAME>
        {$i/FIRST_NAME/text()}_{$i/LAST_NAME/text()}
      </EMPLOYEE_NAME>
    </EMPLOYEE>' );




/* F�hren Sie den folgenden Code aus. Damit wird die im folgenden
zu verwendende Tabelle erzeugt und gef�llt.
*/

-- DROP TABLE prac_path;
CREATE TABLE prac_path OF XMLType;

INSERT INTO prac_path VALUES (
XMLType('<PurchaseOrder>
   <Actions>
      <Action>
         <Customer>SCOTT</Customer>
        </Action>
   </Actions>
   <Reject/>
   <Requestor>Julie P. Adams</Requestor>
   <User>ADAMS</User>
   <CostCenter>R20</CostCenter>
   <ShippingInstructions>
      <name>Julie P. Adams</name>
      <address>300 Oracle Parkway</address>
      <telephone>650 506 7300</telephone>
   </ShippingInstructions>
   <SpecialInstructions>Surface Mail</SpecialInstructions>
   <LineItems>
      <LineItem ItemNumber="1">
         <Description>Notorious</Description>
         <Part Id="715515012720" UnitPrice="39.95" Quantity="1"/>
      </LineItem>
      <LineItem ItemNumber="2">
         <Description>Samurai Three: Duel at Ganryu Island</Description>
         <Part Id="037429125625" UnitPrice="29.95" Quantity="1"/>
      </LineItem>
      <LineItem ItemNumber="3">
         <Description>A Night to Remember</Description>
         <Part Id="715515009058" UnitPrice="39.95" Quantity="3"/>
      </LineItem>
      <LineItem ItemNumber="4">
         <Description>Time Bandits</Description>
         <Part Id="715515010122" UnitPrice="39.95" Quantity="3"/>
      </LineItem>
     </LineItems>
</PurchaseOrder>'));



/*
Bei dem Zugriff auf den XML-Content k�nnen Sie fn:collection"
verwenden, um den Content f�r die Xquery-Ausdr�cke zur Verf�gung zu stellen.

Aufgabe a: Testen Sie das durch Ausgabe des gesamten Inhalts
*/
SELECT XMLQUery(
  'for $i in fn:collection("oradb:/HR/PRAC_PATH")
    return $i'
  RETURNING CONTENT) as res
FROM DUAL;

/* Aufgabe b: Geben Sie nur die Elemente "ShippingInstructions" aus
*/
SELECT XMLQUery(
 'for $i in fn:collection("oradb:/HR/PRAC_PATH")//ShippingInstructions
    return $i'
  RETURNING CONTENT) as res
FROM DUAL;

-- sofern Probleme mit der Darstellung konvertieren zur Zeichenkette mit 
-- XMLSerialize
SELECT XMLSerialize(CONTENT XMLQUery(
 'for $i in fn:collection("oradb:/HR/PRAC_PATH")//ShippingInstructions
    return $i'
  RETURNING CONTENT)) as res
FROM DUAL;


/* Aufgabe c: Geben Sie das 2. "LineItem"-Element aus */
SELECT XMLQUery(
  'for $i in fn:collection("oradb:/HR/PRAC_PATH")//LineItems/LineItem[2]
  return $i'
 RETURNING CONTENT) as res
FROM DUAL;


/* Aufgabe d: Geben Sie die "LineItem"-Elemente mit der 
ItemNumber 1 und 4 aus
*/
-- getStringVal nur bei Probblemen mit der Darstellung
SELECT XMLQUery(
'for $i in fn:collection(
  "oradb:/HR/PRAC_PATH")//LineItems/LineItem[@ItemNumber="1" or @ItemNumber="4"]
  return $i'
 RETURNING CONTENT).getStringVal() as res
FROM DUAL;


/* Aufgabe e: Geben Sie das "LineItem"-Element mit der Description
           "A Night to Remember" aus
*/
SELECT XMLQUery(
'for $i in fn:collection(
   "oradb:/HR/PRAC_PATH")//LineItems/LineItem[Description ="A Night to Remember"]
  return $i'
  RETURNING CONTENT).getStringVal() as res
FROM DUAL;



/* Geben Sie die Tabelle HR.EMPLOYEES in folgendem Format 
zeilenweise aus:

<EMPLOYEE id="100"><EMPLOYEE_NAME>Steven_K�nig</EMPLOYEE_NAME>
  <Incremented_salary>NA</Incremented_salary></EMPLOYEE>
<EMPLOYEE id="101"><EMPLOYEE_NAME>Neena_Kochhar</EMPLOYEE_NAME>
  <Incremented_salary>NA</Incremented_salary></EMPLOYEE>
...
<EMPLOYEE id="105"><EMPLOYEE_NAME>David_Austin</EMPLOYEE_NAME>
  <Incremented_salary>5800</Incremented_salary></EMPLOYEE>
...

"Incremented_salary" soll dabei das vorhandene "salary + 1000" sein, falls
"salary" maximal 10000, ansonsten "NA"

*/
SELECT * FROM XMLTable('
  for $i in fn:collection("oradb:/HR/EMPLOYEES")/ROW
    where $i/EMPLOYEE_ID/text() < 110
  return
    <EMPLOYEE id="{$i/EMPLOYEE_ID}">
      <EMPLOYEE_NAME>
        {$i/FIRST_NAME/text()}_{$i/LAST_NAME/text()}
      </EMPLOYEE_NAME>
      <Incremented_salary>
        {if ($i/SALARY/text() > 10000)
          then "NA"
          else ($i/SALARY/text())+1000}
      </Incremented_salary>
    </EMPLOYEE>');  
    
    
    
/* Verwendung von XQuery-Funktionen
Komplettieren Sie den folgenden Code, so dass die Bestellungen wie 
folgt zeilenweise ausgegeben werden:

"<OrderTotal><Reference>EABEL-20021009123335791PDT</Reference>
   <Total>2067,15</Total><NumOfItems>21</NumOfItems>
          <MaxPrice>179,85</MaxPrice></OrderTotal>"
...

Dabei soll das Element "Total" den summierten Bestellwert u�ber alle "Part"
enthalten (Funktion fn:sum),
das Element "NumOfItems" die Anzahl der Einzelteile ("Part") in der jeweiligen
Bestellung (Funktion fn:count),
das Element "MaxPrice" den maximalen Preis eines Einzelteils (Funktion fn:max)
*/
SELECT ttab.COLUMN_VALUE AS OrderTotal FROM purchaseorder,
XMLTable(
 'for $i in /PurchaseOrder
  where $i/User = "EABEL"
  return  <OrderTotal> {$i/Reference}
		  <Total>
			{fn:sum(for $j in $i/LineItems/LineItem/Part
				return ($j/@Quantity*$j/@UnitPrice))
			}
		  </Total>
		  <NumOfItems>
			{fn:count(for $j in $i/LineItems/LineItem/Part
			return ($j/@Quantity*$j/@UnitPrice))
			}
		  </NumOfItems>
		  <MaxPrice>
			{fn:max(for $j in $i/LineItems/LineItem/Part
				return ($j/@Quantity*$j/@UnitPrice))
			}
		  </MaxPrice>
		</OrderTotal>'
  PASSING OBJECT_VALUE) ttab;