
public class Greeting
{
  public static void main(String[] argv)
  {
    System.out.println("Hello, World!");
  }
}
    