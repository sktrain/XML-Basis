-- bsp aus der doku
SELECT XMLSerialize(DOCUMENT XMLType('<poid>143598</poid>') AS CLOB) 
                    AS xmlserialize_doc
FROM DUAL;

SELECT XMLSERIALIZE(CONTENT XMLTYPE(
  '<Tag1>Hier kommen die Testdaten</Tag1>  <Leer/>', wellformed => 1)) 
      AS xml_doc
FROM DUAL;   -- liefert CLOB, CONTENT erlaubt auch XML_Fragmente

SELECT XMLSERIALIZE(DOCUMENT XMLTYPE('<Tag1>Hier kommen die Testdaten</Tag1>')
                      AS VARCHAR2(50))  AS xml_doc
FROM DUAL;   -- liefert VARCHAR, DOCUMENT verlangt wohlgeformt

-- mit �berpr�fung wohlgeformt
SELECT XMLSERIALIZE( Document XMLELEMENT("Emp", XMLELEMENT("Name", e.job_id
  ||' '
  ||e.last_name), XMLELEMENT(hire_date, e.hire_date))) AS "Result"
FROM employees e
WHERE employee_id = 100;

-- mit �berpr�fung wohlgeformt (mixed content ist ok)
-- f�r jeden R�ckgabewert, aber nicht f�r die Gesamtheit (viele Zeilen)
SELECT XMLSerialize(Document XMLELEMENT(department_name, -- hier ist kein Tab.-Alias erlaubt!!
                                XMLELEMENT(first_name, first_name), 
                                XMLELEMENT(last_name, last_name),
                                DEPARTMENT_NAME)) AS result
FROM departments d
JOIN employees e
ON d.department_id = e.department_id;

-- mit �berpr�fung wohlgeformt und pretty print
SELECT XMLSERIALIZE( Document 
    XMLELEMENT("Emp", 
       XMLELEMENT("Name", e.job_id ||' '||e.last_name), 
       XMLELEMENT(hire_date, e.hire_date)) 
  INDENT --SIZE = 10
  ) AS "Result"
FROM employees e
WHERE employee_id = 100;













