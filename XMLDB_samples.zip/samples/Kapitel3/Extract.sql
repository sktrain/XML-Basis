-- extract und extractValue sind deprecated

/* aus der Doku:
Note:
extract(), transform(), and existsNode() methods only work with the Thick
JDBC driver.
Not all oracle.xdb.XMLType functions are supported by the Thin JDBC driver.
However, if you do not use oracle.xdb.XMLType classes and OCI driver, you
could loose performance benefits associated with the intelligent handling
of XML.
*/

-- von daher Erg�nzung mit getStringVal()
SELECT warehouse_name,
  EXTRACT(warehouse_spec, '/Warehouse/Docks').getStringVal() "Number of Docks with Markup",
  EXTRACT(warehouse_spec, '/Warehouse/Docks/text()').getStringVal() "Number of Docks (String)",
  EXTRACT(warehouse_spec, '/Warehouse/Docks/text()').getNumberVal() "Number of Docks (Number)"
FROM warehouses
WHERE warehouse_spec IS NOT NULL
ORDER BY warehouse_name;

-- extractValue liefert von vornherein nur den Wert
SELECT warehouse_name, 
       EXTRACTVALUE(e.warehouse_spec, '/Warehouse/Docks') "Docks"
FROM warehouses e
WHERE warehouse_spec IS NOT NULL
ORDER BY warehouse_name;