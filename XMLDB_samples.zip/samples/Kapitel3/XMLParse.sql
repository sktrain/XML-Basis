-- Bsp aus Doku:
-- wellformed wird hier nicht gepr�ft!!
SELECT XMLParse(CONTENT '124 <purchaseOrder poNo="12435">
                            <customerName> Acme Enterprises</customerName>
                            <itemNo>32987457</itemNo>
                            </purchaseOrder>' WELLFORMED) AS po
FROM DUAL d;