DROP TABLE xml_test;

-- Verwendung als Spaltentyp
CREATE TABLE x( o_number NUMBER(10),
                        o_doc XMLTYPE
                      );

INSERT INTO order_tab(o_number, o_doc)
    VALUES (1,XMLType('<sample>Beispielstext</sample>'));


-- oder auch bei nur einer Spalte
CREATE TABLE XML_Test OF XMLTYPE;

INSERT INTO XML_Test 
  VALUES (XMLType('<sample>Test</sample>'));
  
SELECT * FROM XML_Test;

SELECT SYS_NC_ROWINFO$ FROM XML_Test;

SELECT OBJECT_VALUE FROM XML_Test;