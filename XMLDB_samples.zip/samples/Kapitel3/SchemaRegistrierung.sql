-- das Schema als XMLTYPE
SELECT XMLType('<xs:schema 
  xmlns:xs="http://www.w3.org/2001/XMLSchema" elementFormDefault="qualified">
  <xs:element name="Termin">
    <xs:complexType>
      <xs:sequence>
        <xs:element name="Beginn" type="xs:string"/>
        <xs:element name="Ende" type="xs:string"/>
        <xs:element name="Kurs" type="xs:int"/>
      </xs:sequence>
      <xs:attribute name="Nr" type="xs:short" use="required"/>
    </xs:complexType>
  </xs:element>
</xs:schema>
') FROM DUAL;

BEGIN
Dbms_xmlschema.deleteSchema(
'http://karrer/termin3.xsd',
dbms_xmlschema.DELETE_CASCADE_FORCE);
END;


-- Registrierung via XMLTYPE
DECLARE 
 shem XMLType := XMLTYPE('<xs:schema 
  xmlns:xs="http://www.w3.org/2001/XMLSchema" elementFormDefault="qualified">
  <xs:element name="Termin">
    <xs:complexType>
      <xs:sequence>
        <xs:element name="Beginn" type="xs:string"/>
        <xs:element name="Ende" type="xs:string"/>
        <xs:element name="Kurs" type="xs:int"/>
      </xs:sequence>
      <xs:attribute name="Nr" type="xs:short" use="required"/>
    </xs:complexType>
   </xs:element>
  </xs:schema>
 ') ;
BEGIN
 DBMS_XMLSCHEMA.REGISTERSCHEMA('http://karrer/termin3.xsd', shem);
END;

-- Registrierung des Schemas via VARCHAR2 funktioniert leider nicht �ber EXEC
-- verschluckt sich wohl an den Sonderzeichen
EXEC DBMS_XMLSCHEMA.REGISTERSCHEMA('http://karrer/termin4.xsd',
   XMLTYPE('<xs:schema 
      xmlns:xs="http://www.w3.org/2001/XMLSchema" elementFormDefault="qualified">
     <xs:element name="Termin">
      <xs:complexType>
        <xs:sequence>
         <xs:element name="Beginn" type="xs:string"/>
         <xs:element name="Ende" type="xs:string"/>
         <xs:element name="Kurs" type="xs:int"/>
        </xs:sequence>
        <xs:attribute name="Nr" type="xs:short" use="required"/>
      </xs:complexType>
    </xs:element>
  </xs:schema>' ));

-- Registrierung vie Zeichenkette im PL/SQL-Block funktioniert  
Begin
DBMS_XMLSCHEMA.REGISTERSCHEMA(
   'http://karrer/termin.xsd',
   '<xs:schema 
  xmlns:xs="http://www.w3.org/2001/XMLSchema" elementFormDefault="qualified">
  <xs:element name="Termin">
    <xs:complexType>
      <xs:sequence>
        <xs:element name="Beginn" type="xs:string"/>
        <xs:element name="Ende" type="xs:string"/>
        <xs:element name="Kurs" type="xs:int"/>
      </xs:sequence>
      <xs:attribute name="Nr" type="xs:short" use="required"/>
    </xs:complexType>
  </xs:element>
</xs:schema>');
end;

-- Anschlie�ende Validierung mittels IsSchemaValid
SELECT XMLType('<Termin Nr="498">
                  <Beginn>10.06.03</Beginn>
                  <Ende>13.06.03</Ende>
                  <Kurs>1015068</Kurs>
                </Termin>').IsSchemaValid( 'http://karrer/termin.xsd') 
        AS status from dual;

-- bzw. via SQL-Funktion mit Angabe des Wurzelelements
SELECT XMLIsValid( XMLType('<Termin Nr="498">
                             <Beginn>10.06.03</Beginn>
                             <Ende>13.06.03</Ende>
                             <Kurs>1015068</Kurs>
                            </Termin>'), 'http://karrer/termin.xsd', 'Termin') 
        AS status from dual;

-- Erzeugung eines Schema-basierten XMLTYPE via VARCHAR2
-- dabei wird allerdings nicht validiert!
SELECT XMLType(xmldata => '<Termin Nr="498">
                            <Beginn>10.06.03</Beginn>
                            <Ende>13.06.03</Ende>
                            <Kurs>1015068</Kurs>
                           </Termin>',
                schema => 'http://karrer/termin.xsd') 
        AS data from dual;

-- PL/SQL-Code zur Pr�fung des Status und  Validierung       
DECLARE
   status NUMBER;
   xmldata XMLTYPE
    :=  XMLType(xmldata => '<Termin Nr="498">
                            <Beginn>10.06.03</Beginn>
                            <Ende>13.06.03</Ende>
                            <Kurs>1015068</Kurs>
                           </Termin>',
                schema => 'http://karrer/termin.xsd');
BEGIN  -- wir k�nnen den Status abfragen
  DBMS_OUTPUT.PUT_LINE('Status ist: ' || xmldata.IsSchemaValidated());
  xmldata.SchemaValidate(); -- bedingte Validierung, sofern Status 0
  DBMS_OUTPUT.PUT_LINE('Status ist: ' || xmldata.IsSchemaValidated());
  xmldata.setSchemaValidated(0);  -- explizites Setzen des Status
  DBMS_OUTPUT.PUT_LINE('Status ist: ' || xmldata.IsSchemaValidated());
end;


-- wir k�nnen den Status abfragen
SELECT XMLType('<Termin Nr="498">
                  <Beginn>10.06.03</Beginn>
                  <Ende>13.06.03</Ende>
                  <Kurs>1015068</Kurs>
                </Termin>').IsSchemaValidated() 
        AS status from dual;