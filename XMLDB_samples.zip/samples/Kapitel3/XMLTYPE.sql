SELECT p.OBJECT_VALUE.getCLOBVal() FROM PURCHASEORDER p
   WHERE ROWNUM = 1;
-- oder auch   
SELECT p.getCLOBVal() FROM PURCHASEORDER p
   WHERE ROWNUM = 1;
   
SELECT p.OBJECT_VALUE.getStringVal() FROM PURCHASEORDER p
   WHERE ROWNUM = 1; 
   
SELECT p.OBJECT_VALUE.getRootElement() FROM PURCHASEORDER p
   WHERE ROWNUM = 1; 
   
SELECT p.OBJECT_VALUE.getSchemaURL() FROM PURCHASEORDER p
   WHERE ROWNUM = 1; 
   
SELECT XMLTYPE('<Number>2</Number>').getStringVal()
FROM DUAL;

SELECT 
        XMLTYPE('<N>2.4</N>').extract('/N/text()') as "Text"
      , XMLTYPE('<N>2.4</N>').extract('/N/text()') as "Number"
FROM DUAL;

select xmlparse(content '<V>5</V> <V></V> <V>46</V>' wellformed) as xml_instance
    from   dual;
    
select XMLTYPE( '<V>5</V> <V></V> <V>46</V>') as xml_instance
    from   dual;

select
  t1_xml_3.num ,
  t1_xml_3.xml_instance ,
  t1_xml_3.xml_instance.extract('/V[1]/text()') as Text_Val_1 ,
  t1_xml_3.xml_instance.extract('/V[1]/text()').GETNUMBERVAL() as N_VAL_1 ,
  t1_xml_3.xml_instance.extract('/V[2]/text()').GETNUMBERVAL() as N_VAL_2 ,
  t1_xml_3.xml_instance.extract('/V[3]/text()').GETNUMBERVAL() as N_VAL_3
from
  ( select
      1 as num,
      xmlparse(content '<V>5</V> <V></V> <V>46</V>' wellformed) as xml_instance
    from   dual
  ) t1_xml_3
;