-- aus der Doku
SELECT XMLParse(CONTENT
'124 <purchaseOrder poNo="12435">
<customerName> Acme Enterprises</customerName>
<itemNo>32987457</itemNo>
</purchaseOrder>'
WELLFORMED)
AS po FROM DUAL d;

-- Gegenst�ck zu XMLSerialize
SELECT XMLParse(DOCUMENT
'<Emp>
  <Name>AD_PRES K�nig</Name>
  <HIRE_DATE>2003-06-17</HIRE_DATE>
</Emp>'
) AS po FROM DUAL d;
