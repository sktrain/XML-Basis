create or replace TYPE Adresse AS OBJECT
( strasse VARCHAR(25),
  nr      NUMBER(5,0),
  ort     VARCHAR(25),
  plz     NUMBER(5,0)
);

SELECT XMLSerialize(CONTENT dbms_xmlschema.generateschema('HR', 'ADRESSE') 
                    INDENT) FROM dual;