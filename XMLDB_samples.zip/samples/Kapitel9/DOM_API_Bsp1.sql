DECLARE
  var XMLType;
  doc DBMS_XMLDOM.DOMDocument;
  ndoc DBMS_XMLDOM.DOMNode;
  buf VARCHAR2(2000);
BEGIN
  var := XMLType('<PERSON><NAME>KING</NAME></PERSON>');
  -- Create DOMDocument handle
  doc  := DBMS_XMLDOM.newDOMDocument(var);
  ndoc := DBMS_XMLDOM.makeNode(doc);
  DBMS_XMLDOM.writeToBuffer(ndoc, buf);
  DBMS_OUTPUT.put_line('Before:'||buf);
END;
/