Drop TABLE person;
/
CREATE TABLE person OF XMLType;
/
DECLARE
  var XMLType;
  doc DBMS_XMLDOM.DOMDocument;
  ndoc DBMS_XMLDOM.DOMNode;
  docelem DBMS_XMLDOM.DOMElement;
  node DBMS_XMLDOM.DOMNode;
  childnode DBMS_XMLDOM.DOMNode;
  nodelist DBMS_XMLDOM.DOMNodelist;
  buf VARCHAR2(2000);
BEGIN
  var := XMLType('<PERSON><NAME>KING</NAME></PERSON>');
  -- Create DOMDocument handle
  doc  := DBMS_XMLDOM.newDOMDocument(var);
  ndoc := DBMS_XMLDOM.makeNode(doc);
  DBMS_XMLDOM.writeToBuffer(ndoc, buf);
  DBMS_OUTPUT.put_line('Before:'||buf);
  docelem := DBMS_XMLDOM.getDocumentElement(doc);
  -- Access element
  nodelist  := DBMS_XMLDOM.getElementsByTagName(docelem, 'NAME');
  node      := DBMS_XMLDOM.item(nodelist, 0);
  childnode := DBMS_XMLDOM.getFirstChild(node);
  -- Manipulate element
  DBMS_XMLDOM.setNodeValue(childnode, 'Rick');
  DBMS_XMLDOM.writeToBuffer(ndoc, buf);
  DBMS_OUTPUT.put_line('After:'||buf);
  DBMS_XMLDOM.freeDocument(doc);
END;
/