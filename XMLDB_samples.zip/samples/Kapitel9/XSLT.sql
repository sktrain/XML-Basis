-- Spieltabelle anlegen
DROP Table emp_resumes;
CREATE TABLE emp_resumes(id number(4), resume XMLType);
-- Einf�gen einer XML-Instanz
INSERT INTO emp_resumes VALUES (10,
			XMLType('<?xml version="1.0"?>
			<RESUME>
				<FULL_NAME>Steven King</FULL_NAME>
				<PHONE>20000</PHONE>
				<JOB_ID>AD_PRES</JOB_ID>
				<LOCATION>Boston</LOCATION>
			</RESUME>'));

-- Tabelle f�r Stylesheets anlegen
drop table stylesheets;
CREATE TABLE stylesheets(id number(4), xsld XMLType);
-- Stylesheet einf�gen
INSERT INTO stylesheets VALUES (1,
		XMLType('<?xml version="1.0"?>
		<xsl:stylesheet version="1.0"
		xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
		<xsl:output encoding="utf-8"/>
		<!-- alphabetizes an xml tree -->
		<xsl:template match="*">
			<xsl:copy>
				<xsl:apply-templates select="*|text()">
					<xsl:sort select="name(.)" data-type="text" order="ascending"/>
				</xsl:apply-templates>
			</xsl:copy>
		</xsl:template>
		<xsl:template match="text()">
			<xsl:value-of select="normalize-space(.)"/>
		</xsl:template>
		</xsl:stylesheet>'));
    
-- Transformation der XML_instanz mittels des Stylesheets    
DECLARE
  indoc  VARCHAR2(2000);
  xsldoc VARCHAR2(2000);
  xsl DBMS_XSLPROCESSOR.stylesheet;
  outdomdocf DBMS_XMLDOM.DOMDocumentFragment;
  node DBMS_XMLDOM.DOMNode;
  PROC DBMS_XSLPROCESSOR.processor;
  buf VARCHAR2(2000);
BEGIN
  SELECT e.resume.getstringval() INTO indoc FROM emp_resumes e WHERE id=10;
  SELECT s.xsld.getstringval() INTO xsldoc FROM stylesheets s WHERE id=1;
  -- Ausgabe vor Ver�nderung
  DBMS_OUTPUT.put_line(indoc);
  -- Transformation
  xsl  := DBMS_XSLPROCESSOR.newStyleSheet(xsldoc, '');
  PROC := DBMS_XSLPROCESSOR.newProcessor;
  outdomdocf := DBMS_XSLPROCESSOR.processXSL(PROC, xsl, indoc);
  -- Ausgabe nach Transformation
  node    := DBMS_XMLDOM.makeNode(outdomdocf);
  DBMS_XMLDOM.writeToBuffer(node, buf);
  DBMS_OUTPUT.put_line(buf);
  DBMS_XMLDOM.freeDocFrag(outdomdocf);
  DBMS_XSLPROCESSOR.freeProcessor(PROC);
END;
