CREATE OR REPLACE PROCEDURE ADDNODE
IS
  var XMLType;
  doc DBMS_XMLDOM.DOMDocument;
  ndoc DBMS_XMLDOM.DOMNode;
  docelem DBMS_XMLDOM.DOMElement;
  node DBMS_XMLDOM.DOMNode;
  childnode DBMS_XMLDOM.DOMNode;
  buf   VARCHAR2(2000);
  v_dir VARCHAR2(2000);
  n_elem DBMS_XMLDOM.DOMElement;
  v_attr DBMS_XMLDOM.DOMAttr;
  n_attr DBMS_XMLDOM.DOMNode;
  n_txt DBMS_XMLDOM.DOMNode;
BEGIN
  v_dir     := 'E:\labs\xml_dir';
  var       := XMLType('<PERSON> <NAME>KING</NAME><SAL>1010</SAL></PERSON>');
  doc       := DBMS_XMLDOM.newDOMDocument(var);
  ndoc      := DBMS_XMLDOM.makeNode(DBMS_XMLDOM.getDocumentElement(doc));
  childnode := DBMS_XMLDOM.getLastChild(ndoc);
  --creating new elements
  n_elem :=DBMS_XMLDOM.createElement (doc,'Specialization');
  v_attr :=DBMS_XMLDOM.createAttribute( doc, 'id');
  n_attr :=DBMS_XMLDOM.MakeNode(v_attr);
  DBMS_XMLDOM.setNodeValue ( n_attr, '1');
  v_attr :=DBMS_XMLDOM.setAttributeNode (n_elem, v_attr);
  node   :=DBMS_XMLDOM.MakeNode(n_elem);
  n_txt  :=DBMS_XMLDOM.MakeNode(DBMS_XMLDOM.createTextNode(doc,'XML'));
  n_txt  :=DBMS_XMLDOM.appendChild( node, n_txt);
  --Adding the new element
  node := DBMS_XMLDOM.insertBefore(ndoc, node, childnode);
  DBMS_XMLDOM.writeToFile(ndoc, v_dir||'\abc.txt');
  DBMS_XMLDOM.freeDocument(doc);
END;
/
EXECUTE addnode
