create or replace procedure useparser is
		indoc VARCHAR2(2000);
		myparser DBMS_XMLPARSER.parser;	
		xmldoc DBMS_XMLDOM.DOMDocument;
		v_dir varchar2(30);
		ndoc DBMS_XMLDOM.DOMNode;
BEGIN
		v_dir := 'E:\labs\xml_dir';
		myParser := DBMS_XMLPARSER.newParser;
		DBMS_XMLPARSER.setBaseDIR(myparser, v_dir);
		DBMS_XMLPARSER.parse(myParser,'projects.xml');
		xmldoc := DBMS_XMLPARSER.getDocument(myParser);
		ndoc := DBMS_XMLDOM.makeNode(xmldoc);
		DBMS_XMLDOM.writeToFile(xmldoc, v_dir||'/DEF.txt');
		DBMS_XMLPARSER.freeParser(myParser);
		DBMS_XMLDOM.freeDocument(xmldoc);
END;
/
show errors
EXECUTE useparser;

