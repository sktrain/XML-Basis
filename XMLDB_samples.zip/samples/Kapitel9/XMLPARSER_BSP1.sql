set serveroutput on
DECLARE
  indoc VARCHAR2(2000);
  indomdoc DBMS_XMLDOM.DOMDocument;
  innode DBMS_XMLDOM.DOMNode;
  myparser DBMS_XMLPARSER.parser;
  buf VARCHAR2(2000);
 BEGIN
  indoc := '<emp><name>KING</name></emp>';
  myParser := DBMS_XMLPARSER.newParser;
  DBMS_XMLPARSER.parseBuffer(myParser, indoc);
  indomdoc := DBMS_XMLPARSER.getDocument(myParser);
  innode := DBMS_XMLDOM.makeNode(indomdoc);
  DBMS_XMLDOM.writeToBuffer(innode, buf);
  DBMS_OUTPUT.put_line(buf);
  DBMS_XMLDOM.freeDocument(indomdoc);
  DBMS_XMLPARSER.freeParser(myParser);
 END;
/
