-- Anlegen einer Spieltabelle
DROP TABLE new_employees;
CREATE TABLE NEW_EMPLOYEES AS SELECT * FROM EMPLOYEES;

-- wie sieht es aus f�r Abteilung 50
SELECT * FROM new_employees WHERE department_id = 50;


-- Insert von 2 Zeilen anhand der XML-Daten (department_id = 50).
-- Vorsicht!!: das korrekte Mapping des Datumswertes h�ngt vom nationalen
-- Kontext ab. Dies ANSI-Schreibweise sollte allerdings stets funktionieren.
-- ALTER SESSION SET NLS_LANGUAGE=German;

DECLARE
  insCtx DBMS_XMLSTORE.ctxType;
  rows NUMBER;
  xmlDoc CLOB :=
    '<ROWSET>
       <ROW num="1">
         <EMPLOYEE_ID>800</EMPLOYEE_ID>
         <SALARY>1000</SALARY>
         <DEPARTMENT_ID>50</DEPARTMENT_ID>
         <HIRE_DATE>2005.05.21</HIRE_DATE>
         <LAST_NAME>Kevin</LAST_NAME>
         <EMAIL>PKEVIN</EMAIL>
         <JOB_ID>ST_CLERK</JOB_ID>
       </ROW>
       <ROW>
         <EMPLOYEE_ID>900</EMPLOYEE_ID>
         <SALARY>3000</SALARY>
         <DEPARTMENT_ID>50</DEPARTMENT_ID>
         <HIRE_DATE>2004.05.12</HIRE_DATE>
         <LAST_NAME>MATHEW</LAST_NAME>
         <EMAIL>JMATHEW</EMAIL>
<JOB_ID>ST_CLERK</JOB_ID>
       </ROW>
     </ROWSET>';
BEGIN
  insCtx := DBMS_XMLSTORE.newContext('HR.NEW_EMPLOYEES');
  DBMS_XMLSTORE.clearUpdateColumnList(insCtx); 
  DBMS_XMLSTORE.setUpdateColumn(insCtx, 'EMPLOYEE_ID'); 
  DBMS_XMLSTORE.setUpdateColumn(insCtx, 'SALARY'); 
  DBMS_XMLSTORE.setUpdateColumn(insCtx, 'HIRE_DATE');
  DBMS_XMLSTORE.setUpdateColumn(insCtx, 'DEPARTMENT_ID'); 
  DBMS_XMLSTORE.setUpdateColumn(insCtx, 'JOB_ID');
  DBMS_XMLSTORE.setUpdateColumn(insCtx, 'EMAIL');
  DBMS_XMLSTORE.setUpdateColumn(insCtx, 'LAST_NAME');
  
  rows := DBMS_XMLSTORE.insertXML(insCtx, xmlDoc);
  DBMS_OUTPUT.put_line(rows || ' rows inserted.');
  DBMS_XMLSTORE.closeContext(insCtx); 
END;

-- wie sieht es jetzt aus f�r Abteilung 50
SELECT * FROM new_employees WHERE department_id = 50;

-- Update des Records mit der employee_id = 144 anhand der XML-Daten

-- wie sieht es zuvor aus:
SELECT * FROM new_employees WHERE employee_id = 144;

DECLARE
  updCtx DBMS_XMLSTORE.ctxType; 
  rows NUMBER;
  xmlDoc CLOB :=
    '<ROWSET>
       <ROW>
         <EMPLOYEE_ID>144</EMPLOYEE_ID>
         <FIRST_NAME>Anderson</FIRST_NAME>
       </ROW>
     </ROWSET>';
BEGIN
   updCtx := DBMS_XMLSTORE.newContext('HR.NEW_EMPLOYEES'); 
   DBMS_XMLSTORE.clearUpdateColumnList(updCtx);        
    -- Spezifikation der employee_id-Spalte als Key zur Identifizierung der
    -- zu aktualisierenden Zeilen
   DBMS_XMLSTORE.setKeyColumn(updCtx, 'EMPLOYEE_ID'); 
   rows := DBMS_XMLSTORE.updateXML(updCtx, xmlDoc);    
   DBMS_XMLSTORE.closeContext(updCtx);                
END;

-- wie sieht es danach aus:
SELECT * FROM new_employees WHERE employee_id = 144;

-- L�schen des Records mit der employee_id = 144
DECLARE
  delCtx DBMS_XMLSTORE.ctxType;
  rows NUMBER;
  xmlDoc CLOB :=
    '<ROWSET>
       <ROW>
          <EMPLOYEE_ID>144</EMPLOYEE_ID>
          <DEPARTMENT_ID>50</DEPARTMENT_ID>
       </ROW>
     </ROWSET>';
BEGIN
  delCtx  := DBMS_XMLSTORE.newContext('HR.NEW_EMPLOYEES');
  DBMS_XMLSTORE.setKeyColumn(delCtx, 'EMPLOYEE_ID');
  rows := DBMS_XMLSTORE.deleteXML(delCtx, xmlDoc);
  DBMS_XMLSTORE.closeContext(delCtx);
END;
