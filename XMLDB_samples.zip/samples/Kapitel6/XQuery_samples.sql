SELECT XMLQuery(
     'ora:view("DEPARTMENTS")'
	 RETURNING CONTENT) AS EMP_DEPARTMENTS
 FROM dual;
 
SELECT XMLQUERY(
    'fn:collection("oradb:/HR/DEPARTMENTS")'
    RETURNING CONTENT) AS EMP_DEPARTMENTS
 FROM dual;
 

-- Query-Ausdruck kann eine Sequenz von atomaren Werten sein
SELECT XMLQUERY('(1,2+3, "a")'
RETURNING CONTENT)as output 
FROM dual;

SELECT XMLQUERY('(1,2+3, "a")'
RETURNING CONTENT)as output 
FROM dual;

SELECT XMLQuery('(1, 2 + 3, "a", 100 to 102, ("x", "y"), <A>33</A>)'
RETURNING CONTENT) AS output
FROM DUAL;

SELECT XMLQuery(' ( <A>33</A>  (: direkt :),
                    element book { 
                      attribute isbn {"isbn-0060229357" }, 
                      element title { "Harold and the Purple Crayon"}, 
                      element author { 
                          element first { "Crockett" }, 
                          element last {"Johnson" } 
                    	} 
                    }   (: brechnet :) 
                ) '
RETURNING CONTENT) AS output
FROM DUAL;

SELECT XMLQUERY(' let $num := 1 (: dies ist ein Kommentar :)
                  let $erg := $num + 2
                  let $str := "Hallo"
                  return ($num, $str, $erg)'
  RETURNING CONTENT) as output FROM dual;

SELECT XMLQUERY(' let $num := 1 
                  (: dies ist ein Kommentar :)
                  let $erg := $num + 2
                  let $str := "Hallo"
                  let $d   := xs:date("2017.1.1")
                  return ($num, $str, $erg, $d)'
  RETURNING CONTENT) as output FROM dual;

SELECT XMLQUERY(' let $num := 1 (: dies ist ein Kommentar :)
                  let $erg := $num + 5E-2
                  let $dec := xs:decimal(2.2)
                  let $str := "Hallo"
                  return ($num, $str, $erg)'
  RETURNING CONTENT) as output FROM dual;
  
DECLARE
  n NUMBER := 2.3;
BEGIN
  DBMS_Output.put_line(n);
END;

SELECT XMLQuery( '
        for $i in fn:collection("oradb:/HR/DEPARTMENTS")
        return $i '
  RETURNING CONTENT)AS DEPARTMENT_NAME
  FROM DUAL;

SELECT XMLQuery( '
        for $i in fn:collection("oradb:/HR/DEPARTMENTS")/ROW
        let $j := 20
        where $i/DEPARTMENT_ID > $j
        order by $i/DEPARTMENT_NAME 
        return $i/DEPARTMENT_NAME/text() '
  RETURNING CONTENT)AS DEPARTMENT_NAME
  FROM DUAL;


/* Folgendes ist gleichwertig */
SELECT XMLQUery(
'for $i in fn:collection("oradb:/HR/DEPARTMENTS")/ROW/DEPARTMENT_NAME[text() = "Administration"] 
return $i'
RETURNING CONTENT) as res
FROM DUAL;

SELECT XMLQUery(
'for $i in ora:view("EMP_DEPARTMENTS")//department
where $i/department_name = "Administration"
return $i'
RETURNING CONTENT)
FROM DUAL;

------------------------------------------------
select XMLQuery( 
'for $i in ora:view("DEPARTMENTS")//ROW
 return $i'
RETURNING CONTENT) AS XMLRES
FROM DUAL;

select XMLQuery( 
'for $i in ora:view("DEPARTMENTS")/ROW
where $i/DEPARTMENT_ID < 30
return <Result>
					<department_name> {$i/DEPARTMENT_NAME/text()}	</department_name>
					<location> { if ($i/LOCATION_ID = 1700)
											then "Seattle"
										else "Elsewhere" }
					</location>
			</Result>'
RETURNING CONTENT) AS XMLRES
FROM DUAL;

SELECT XMLQuery(
'some $i in (1 , 2), $j in (22, 4, 2)
satisfies $i = $j'
RETURNING CONTENT) AS SOME
FROM DUAL;

SELECT XMLQUERY(' declare namespace myns = "stephan"; 
                  declare variable $maxItems := 12;
                  (: dies ist ein Kommentar: Ende des Prologs :)
                  let $num := $maxItems
                  let $str := "Hallo"
                  return ($num, $str, $maxItems )'
  RETURNING CONTENT) as output FROM dual;

SELECT XMLQUERY(' declare default namespace "http://stephan"; 
                  declare variable $maxItems := 12;
                  (: dies ist ein Kommentar: Ende des Prologs :)
                  let $num := $maxItems
                  let $str := "Hallo"
                  return ($num, $str, $maxItems )'
  RETURNING CONTENT) as output FROM dual;

SELECT XMLQUERY(' 
    declare namespace prod = "http://datypic.com/prod";
    declare variable $catalog := doc("catalog.xml")//catalog;
    <firstResult>{count($catalog/product)}</firstResult>,
    <prod:secondResult>{$catalog/product/number}</prod:secondResult>'
  RETURNING CONTENT) as output FROM dual;  
  
SELECT XMLQUERY(' 
    declare variable $catalog := doc("catalog.xml")//catalog;
    <firstResult>{count($catalog/product)}</firstResult>,
    <prod:secondResult>{$catalog/product/number}</prod:secondResult>'
  RETURNING CONTENT) as output FROM dual;  

