/* Dictionary Views */

-- registered schemas
SELECT * FROM ALL_XML_SCHEMAS;

DESCRIBE ALL_XML_SCHEMAS;

-- XMLType-Tables
SELECT * FROM ALL_XML_TABLES;

-- XMLType-Table-Columns
SELECT * FROM ALL_XML_TAB_COLS;

-- XMLType-Views
SELECT * FROM ALL_XML_VIEWS;

-- XMLType-Views-Columns
SELECT * FROM ALL_XML_VIEW_COLS;