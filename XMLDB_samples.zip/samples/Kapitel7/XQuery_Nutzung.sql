connect hr/hr;
-- Bereitstellung relationaler Daten im XML-Format via XQuery
SELECT XMLQuery(
     'for $i in fn:collection("oradb:/HR/DEPARTMENTS")/ROW
      where $i/DEPARTMENT_NAME 
            = "Human Resources" 
       return $i'   
       RETURNING CONTENT) AS HR
 FROM dual;
 
-- Join mit XQuery 
SELECT XMLQuery(
  'for $i in fn:collection("oradb:/HR/EMPLOYEES")/ROW
   return <Employee id ="{$i/EMPLOYEE_ID/text()}">
          <Department> 
          {for $j in fn:collection("oradb:/HR/DEPARTMENTS")/ROW
          where $j/DEPARTMENT_ID eq $i/DEPARTMENT_ID
          return ($j/DEPARTMENT_NAME, $j/LOCATION_ID)}
          </Department>
         </Employee>'
RETURNING CONTENT) AS res FROM DUAL;


connect oe/oe;

-- Abfrage von XML mit XQquery 
SELECT XMLQuery(
     'fn:collection("oradb:/OE/PURCHASEORDER")'
	 RETURNING CONTENT) AS res
 FROM dual;
 
SELECT XMLQuery(
    'for $i in /PurchaseOrder return $i'
 		PASSING OBJECT_VALUE
    RETURNING CONTENT) AS res
 FROM OE.PURCHASEORDER;

SELECT xtab.column_value
FROM purchaseorder p,
    XMLTable('for $i in /PurchaseOrder
              where $i/CostCenter eq "A10"
              return 
                 <A10po pono="{$i/Reference}"/>'
              PASSING OBJECT_VALUE                        
) xtab;

SELECT xtab.poref, xtab.usr, xtab.requestor
FROM purchaseorder,
    XMLTable(
     'for $i in /PurchaseOrder
      where $i/CostCenter eq "A10"
      return $i'
    PASSING OBJECT_VALUE
    COLUMNS
     poref VARCHAR2(20) PATH 'Reference',
     usr   VARCHAR2(20) PATH 'User'
                         DEFAULT 'Unknown',
     requestor VARCHAR2(20) PATH 'Requestor'
  ) xtab;


-- Filterung mit XMLExists
SELECT XMLSerialize(CONTENT OBJECT_VALUE)
FROM purchaseorder
WHERE XMLExists('/PurchaseOrder[SpecialInstructions="Expedite"]'
PASSING OBJECT_VALUE);

SELECT XMLCast(XMLQuery('/PurchaseOrder/Reference' PASSING OBJECT_VALUE
RETURNING CONTENT)
AS VARCHAR2(100)) "REFERENCE"
FROM purchaseorder
WHERE XMLExists('/PurchaseOrder[SpecialInstructions="Expedite"]'
PASSING OBJECT_VALUE);


connect hr/hr;
-- Generierung via XQuery
SELECT XMLQuery(
 'for $j in 1
  return (
  <EMPLOYEES> {
   for $i in ora:view("HR", "employees")/ROW
   where $i/EMPLOYEE_ID <= 102
   return (<EMPLOYEE>
               <EMPNO>{xs:string($i/EMPLOYEE_ID)}</EMPNO>
                <ENAME>{xs:string($i/LAST_NAME)}</ENAME>
                <SAL>{xs:integer($i/SALARY)}</SAL>
           </EMPLOYEE>)} </EMPLOYEES>)'
  RETURNING CONTENT)  FROM DUAL;
  
SELECT ttab.COLUMN_VALUE AS OrderTotal FROM purchaseorder,
 XMLTable(
 'for $i in /PurchaseOrder
  where $i/User = "EABEL"
   return  <OrderTotal> {$i/Reference}
    <Total>
     {fn:sum(for $j in $i/LineItems/LineItem/Part
     return ($j/@Quantity*$j/@UnitPrice))}
    </Total>
    </OrderTotal>'
    PASSING OBJECT_VALUE) ttab;


-- connect hr/hr
-- XMLQuery versus XMLTable
SELECT  * FROM XMLTABLE('
 for $i in ora:view("HR","DEPARTMENTS")/ROW
 return
  <Department id="{$i/DEPARTMENT_ID}">
   <Employees>
   {
     for $j in ora:view("HR","EMPLOYEES")/ROW 
     where $j/DEPARTMENT_ID eq $i/DEPARTMENT_ID 
 return ($j/FIRST_NAME,
             $j/LAST_NAME, 
             $j/SALARY) 
   } 
    </Employees>
    </Department>'  );
    
SELECT XMLQUERY('
 for $i in ora:view("HR","DEPARTMENTS")/ROW
 return
  <Department id="{$i/DEPARTMENT_ID}">
   <Employees>
   {
     for $j in ora:view("HR","EMPLOYEES")/ROW 
     where $j/DEPARTMENT_ID eq $i/DEPARTMENT_ID 
 return ($j/FIRST_NAME,
             $j/LAST_NAME, 
             $j/SALARY) 
   } 
    </Employees>
    </Department>' returning content) FROM dual;

