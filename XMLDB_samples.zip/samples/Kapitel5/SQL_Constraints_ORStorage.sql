BEGIN
DBMS_XMLSCHEMA.deleteSchema(
SCHEMAURL => 'deposit.xsd',
DELETE_OPTION => dbms_xmlschema.DELETE_CASCADE_FORCE);
END;
/

DECLARE 
depositschema VARCHAR2(2000) := '<xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema"           xmlns:xdb="http://xmlns.oracle.com/xdb"> 
<xs:element name="Deposit"> 
<xs:complexType xdb:SQLType="Acct">
<xs:sequence>
<xs:element name="Dep_No" type="xs:float" nillable="false"/> 
<xs:element name="Dep_Id" type="xs:float"/>
<xs:element name="Bal" type="xs:float" default="0"                           nillable="false"/> 
<xs:element name="Limit" type="xs:float"/>
<xs:element name="Dep_Date" type="xs:date"/> 
<xs:element name="Dep_Type" type="xs:string"/> 
<xs:element name="Dep_Open" type="xs:boolean"/>          </xs:sequence> 
 </xs:complexType>
 </xs:element>
 </xs:schema>'; 
  BEGIN     
 DBMS_XMLSCHEMA.RegisterSchema('deposit.xsd', depositschema ); 
 END;
/

--drops table if already exits
DROP TABLE deposits;
--creates table
CREATE TABLE deposits OF XMLType( CONSTRAINT "Dep_Id_PK" PRIMARY KEY 
(xmldata."Dep_Id")) XMLSCHEMA "deposit.xsd" ELEMENT "Deposit";
