--deletes schema if already exists
BEGIN
DBMS_XMLSCHEMA.deleteSchema(
SCHEMAURL => 'empreftab.xsd',
DELETE_OPTION => dbms_xmlschema.DELETE_CASCADE_FORCE);
END;
/
--registers schema
DECLARE
doc VARCHAR2(3000) :=
'<schema xmlns="http://www.w3.org/2001/XMLSchema"
targetNamespace="http://www.oracle.com/emp.xsd"
xmlns:emp="http://www.oracle.com/emp.xsd"
xmlns:xdb="http://xmlns.oracle.com/xdb"
xdb:storeVarrayAsTable="true">
<complexType name="EmpType" xdb:SQLType="EMP_T3">
<sequence>
<element name="Name" type="string"/>
<element name="Age" type="decimal"/>
<element name="Addr" xdb:SQLInline="false"
maxOccurs="unbounded" xdb:defaultTable="ADDR_TAB3">
<complexType xdb:SQLType="ADDR_T3">
<sequence>
<element name="Street" type="string"/>
<element name="City" type="string"/>
</sequence>
</complexType>
</element>
</sequence>
</complexType>
<element name="Employee" type="emp:EmpType"
xdb:defaultTable="EMP_TAB3"/>
</schema>';
BEGIN
DBMS_XMLSCHEMA.registerSchema('empreftab.xsd', doc);
END;
/

SELECT TABLE_NAME
FROM USER_NESTED_TABLES
WHERE PARENT_TABLE_NAME = 'EMP_TAB3';

-- potentielles umbenbennen: 
RENAME "SYS_NTJydFMZC0TOqpi2t5QD9etA=="  -- generierter Name ist einzusetzen
  TO emp_tab3_reflist;

-- Indizierung  
ALTER TABLE emp_tab3_reflist ADD SCOPE FOR (column_value) IS addr_tab3;
DROP INDEX reflist_idx;
CREATE INDEX reflist_idx ON emp_tab3_reflist (column_value);

CREATE INDEX city_idx ON addr_tab3 p (extractValue(OBJECT_VALUE, '/Addr/City'));

