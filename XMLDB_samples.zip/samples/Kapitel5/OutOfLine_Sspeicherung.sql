BEGIN
DBMS_XMLSCHEMA.deleteSchema(
SCHEMAURL => 'emp.xsd',
DELETE_OPTION => dbms_xmlschema.DELETE_CASCADE_FORCE);
END;
/
--registers the schema
DECLARE
 doc VARCHAR2(3000) :=
 '<schema xmlns="http://www.w3.org/2001/XMLSchema"
 targetNamespace="http://www.oracle.com/emp.xsd"
 xmlns:emp="http://www.oracle.com/emp.xsd"
 xmlns:xdb="http://xmlns.oracle.com/xdb">
 <complexType name="EmpType" xdb:SQLType="EMPL_T">
 <sequence>
 <element name="Name" type="string"/>
 <element name="Age" type="decimal"/>
 <element name="Addr"
 xdb:SQLInline="false"
 xdb:defaultTable="ADDR_TAB">
 <complexType xdb:SQLType="ADDR_T">
 <sequence>
 <element name="Street" type="string"/>
 <element name="City" type="string"/>
 </sequence>
 </complexType>
 </element>
 </sequence>
 </complexType>
 <element name="Employee" type="emp:EmpType"
 xdb:defaultTable="EMPL_TAB"/>
 </schema>';
 BEGIN
 DBMS_XMLSCHEMA.registerSchema('emp.xsd', doc);
 END;
 /
DESCRIBE EMPL_T;
DESCRIBE ADDR_T;

-- use
INSERT INTO empl_tab
VALUES
(XMLType('<x:Employee
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
xmlns:x="http://www.oracle.com/emp.xsd"
xsi:schemaLocation="http://www.oracle.com/emp.xsd emp.xsd">
<Name>Kiran kumar</Name>
<Age>22</Age>
<Addr>
<Street>ABC Street</Street>
<City>San Francisco</City>
</Addr>
</x:Employee>'));
INSERT INTO empl_tab
VALUES
(XMLType('<x:Employee
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
xmlns:x="http://www.oracle.com/emp.xsd"
xsi:schemaLocation="http://www.oracle.com/emp.xsd emp.xsd">
<Name>Aman Gupta</Name>
<Age>24</Age>
<Addr>
<Street>XYZ Street</Street>
<City>Redwood City</City>
</Addr>
</x:Employee>'));
/

-- query
SELECT DISTINCT extractValue(OBJECT_VALUE, '/Addr/City') AS city FROM addr_tab;
