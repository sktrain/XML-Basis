/* Schema-Based Speicherung */

-- Erstmal alles forciert l�schen, falls schon vorhanden
-- geht auch via SQL-Developer
BEGIN DBMS_XMLSchema.deleteSchema(schemaurl=>'http://karrer/termin.xsd', 
             delete_option=>DBMS_XMLSchema.Delete_Cascade_Force); 
END;

-- Registrierung des Schemas f�r Binary Storage      
BEGIN  DBMS_XMLSCHEMA.REGISTERSCHEMA(
         'http://karrer/termin.xsd',
         '<xs:schema 
          xmlns:xs="http://www.w3.org/2001/XMLSchema" elementFormDefault="qualified">
           <xs:element name="Termin">
            <xs:complexType>
              <xs:sequence>
                <xs:element name="Beginn" type="xs:string"/>
                <xs:element name="Ende" type="xs:string"/>
                <xs:element name="Kurs" type="xs:int"/>
              </xs:sequence>
              <xs:attribute name="Nr" type="xs:short" use="required"/>
             </xs:complexType>
            </xs:element>
          </xs:schema>',
          gentypes => false,
          gentables => false,
          options => DBMS_XMLSCHEMA.REGISTER_BINARYXML);  -- Voraussetzung f�r Binary Storage
END; 

-- Erzeugung der Tabelle, 
-- schl�gt fehl, wenn das Schema nicht f�r Binary Storage registriert ist!
CREATE TABLE Termine (termin XMLTYPE)
            XMLTYPE COLUMN termin
            STORE AS BINARY XML
            XMLSCHEMA "http://karrer/termin.xsd"
            ELEMENT "Termin"  -- Root-Element muss auch angegeben werden
            ;
/* alternative Schreibweise:
CREATE TABLE Termine (termin XMLTYPE)
            XMLTYPE COLUMN termin
            STORE AS BINARY XML
            ELEMENT "http://karrer/termin.xsd#Termin";  -- Root-Element 
*/   


-- Einf�gen eines Termins
INSERT INTO Termine VALUES (XMLType('<Termin Nr="498">
                  <Beginn>10.06.03</Beginn>
                  <Ende>13.06.03</Ende>
                  <Kurs>1015068</Kurs>
                </Termin>'));
                
-- Pr�fung ob validiert (Flag abfragen)
-- interessant: Flag wird nicht gesetzt
DECLARE 
   res XMLTYPE;
BEGIN
 SELECT termin into res  FROM Termine WHERE ROWNUM = 1;
 DBMS_OUTPUT.PUT_LINE(res.IsSchemaValidated());
END;

-- Der Aufruf der Member.Variablen geht �brigens auch mit SQL
SELECT t.termin.IsSchemaValidated() FROM Termine t;

-- Pr�fen, ob valide
SELECT t.termin.IsSchemaValid() FROM Termine t;


-- Einf�gen eines Termins, der nicht valide ist
INSERT INTO Termine VALUES (XMLType('<Termin>
                  <Beginn>10.06.03</Beginn>
                  <Ende>13.06.03</Ende>
                  <Kurs>1015068</Kurs>
                </Termin>'));
    -- schl�gt fehl, da Schema verletzt: Pflichtattribut bei Termin fehlt!      


-- hier hilft uch das explizite Setzen des validated-Flags nicht!
-- (Stezen des Flags via setSchemaValidated(1) ist nur in PL/SQL m�glich)
DECLARE
   status NUMBER;
   xmldata XMLTYPE
    :=  XMLType(xmldata => '<Termin>
                            <Beginn>10.06.03</Beginn>
                            <Ende>13.06.03</Ende>
                            <Kurs>1015068</Kurs>
                           </Termin>',
                schema => 'http://karrer/termin.xsd');
BEGIN  -- wir k�nnen den Status abfragen
  --DBMS_OUTPUT.PUT_LINE('Status: ' || xmldata.IsSchemaValidated());
  --xmldata.SchemaValidate(); -- bedingte Validierung, sofern Status 0
  --DBMS_OUTPUT.PUT_LINE('Status: ' || xmldata.IsSchemaValidated());
  xmldata.setSchemaValidated(1);  -- explizites Setzen des Status
  DBMS_OUTPUT.PUT_LINE('Status: ' || xmldata.IsSchemaValidated());
  insert INTO termine values (xmldata);
end;      


-- Aufr�umen
DROP TABLE termine;
            
