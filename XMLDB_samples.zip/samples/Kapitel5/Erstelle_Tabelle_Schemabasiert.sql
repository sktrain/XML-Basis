--Deletes the schema if already exits
BEGIN
Dbms_xmlschema.deleteSchema(
'http://www.oracle.com/employees.xsd',
dbms_xmlschema.DELETE_CASCADE_FORCE);
END;
/
--Register the schema
BEGIN
DBMS_XMLSCHEMA.registerSchema('http://www.oracle.com/employees.xsd',
 '<schema xmlns="http://www.w3.org/2001/XMLSchema"
 targetNamespace="http://www.oracle.com/employees.xsd" version="1.0"
 xmlns:xdb="http://xmlns.oracle.com/xdb"
 elementFormDefault="qualified">
 <element name = "employees">
 <complexType>
 <sequence>
<element name = "First_Name" type = "string"/><element name = "Last_Name" type = "string"/>
 <element name = "Email" type = "string"/>
 <element name = "Manager" type = "positiveInteger"/>
 <element name = "HireDate" type = "date"/>
 <element name = "Salary" type = "positiveInteger"/>
 <element name = "Commission" type = "positiveInteger"/>
 <element name = "Dept">
 <complexType>
 <sequence>
 <element name = "DeptNo" type = "positiveInteger" />
 <element name = "DeptName" type = "string"/>
 <element name = "Location" type = "positiveInteger"/>
 </sequence>
 </complexType>
 </element>
 </sequence>
 </complexType>
 </element>
 </schema>',
 TRUE,
 TRUE,
 FALSE);
 END;
/

--drops table if already exists
DROP TABLE employees_tab;
--creates table
CREATE TABLE employees_tab of XMLType
XMLTYPE STORE AS CLOB
XMLSCHEMA " http://www.oracle.com/employees.xsd"
ELEMENT "employees";
