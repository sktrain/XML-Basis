--drops table if already exists
DROP TABLE emp_resume;
--creates table
CREATE TABLE emp_resume (employee_id NUMBER(6) PRIMARY KEY, resume XMLTYPE);

--drops table if already exists
DROP TABLE emp_xmlresume;
--creates table
CREATE TABLE emp_xmlresume OF XMLTYPE;
