DROP TABLE po_sample;

CREATE TABLE po_sample(
      id VARCHAR2(100),
      val XMLTYPE);

INSERT INTO po_sample
   SELECT EXTRACTVALUE(VALUE(p), 
            '/PurchaseOrder/Reference'),
          VALUE(p)
      FROM purchaseorder p;
   
      


SELECT * From po_sample;

UPDATE po_sample p set p.val= 
    INSERTCHILDXML(p.val,   
    '/PurchaseOrder/ShippingInstructions', 
    'name',   
    XMLType('<name>Stephan Karrer</name>')) 
WHERE id LIKE '%5771%';

UPDATE po_sample p SET val =
   INSERTXMLBEFORE(val,     
                   '/PurchaseOrder/Actions',
                   XMLType('<name>Stephan Karrer</name>'))
 WHERE id LIKE '%5771%'; 