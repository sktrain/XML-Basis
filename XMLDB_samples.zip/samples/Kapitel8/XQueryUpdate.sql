CREATE TABLE emp_sample AS  
  SELECT employee_id as empid, 
         XMLELEMENT("Employee",  
                  XMLATTRIBUTES( e.employee_id as "id"), 
                  XMLFOREST (e.last_name as "Name", 
                             e.salary as "Salary", 
                             e.department_id as "Dept_ID") 
                  ) AS val FROM hr.employees e;
                  
SELECT * FROM emp_sample;

UPDATE emp_sample set val =  
    XMLQuery('copy $tmp := . modify insert node  
              <Comment>Kommentar</Comment> into $tmp/Employee 
              return $tmp' 
              PASSING val  
              RETURNING CONTENT) 
    WHERE empid = 100;
    
SELECT * FROM emp_sample where empid = 100;

UPDATE emp_sample e set e.val =  
    XMLQuery('copy $tmp := . modify insert node attribute  
              test {x} into $tmp/Employee 
              return $tmp' 
              PASSING e.val  
              RETURNING CONTENT) 
    WHERE empid = 100;
    
SELECT * FROM emp_sample where empid = 100;

UPDATE emp_sample e set e.val =  
    XMLQuery('copy $tmp := . modify insert node 
              attribute murks3{$x}) into $tmp/Employee 
              return $tmp' 
              PASSING e.val, 'murksi' as x
              RETURNING CONTENT) 
    WHERE empid = 100;
    
-- das funktioniert:
UPDATE emp_sample  set val =  
    XMLQuery('copy $tmp := . modify
                (for $i in $tmp/Employee
                 return insert node attribute name2{$NEU} into $i
                )
         return $tmp'
         PASSING val ,'vnameneu' AS neu RETURNING CONTENT) 
   WHERE empid = 100;
-- das funktioniert auch
UPDATE emp_sample  set val =  
    XMLQuery('copy $tmp := . modify
                insert node attribute name3{$NEU} into $tmp/Employee
                
         return $tmp'
         PASSING val ,'vnameneu' AS neu RETURNING CONTENT) 
   WHERE empid = 100;
   
-- das auch
UPDATE emp_sample  set val =  
    XMLQuery('copy $tmp := . modify
              insert node attribute Unit{$NEU} 
              into $tmp/Employee/Salary
              return $tmp'
         PASSING val ,'Euro' AS neu RETURNING CONTENT) 
   WHERE empid = 100;

-- das funktioniert!!
WITH DATA AS
(SELECT xmltype('
<xml>
<root>
<mitarbeiter name="ABC">1</mitarbeiter>
<mitarbeiter name="DEF">2</mitarbeiter>
<mitarbeiter name="HIJ" vorname="xxx">3</mitarbeiter>
<bla><mitarbeiter name="KLM" vorname="123">4</mitarbeiter></bla>
<chef name="GGG" vorname="hffhh">5</chef>
</root>
</xml>') AS x FROM dual)
SELECT XMLQuery('copy $tmp := . modify
(for $i in $tmp//*/mitarbeiter[@vorname]
return insert node attribute name2{$NEU} into $i
)
return $tmp'
PASSING x ,'vnameneu' AS neu RETURNING CONTENT) xq
FROM DATA;