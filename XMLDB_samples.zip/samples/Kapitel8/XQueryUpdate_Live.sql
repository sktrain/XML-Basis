REM   Script: XQueryUpdateFacility
REM   Durchspielen von XQuery Update

CREATE TABLE emp_sample AS   
  SELECT employee_id as empid,  
         XMLELEMENT("Employee",   
                  XMLATTRIBUTES( e.employee_id as "id"),  
                  XMLFOREST (e.last_name as "Name",  
                             e.salary as "Salary",  
                             e.department_id as "Dept_ID")  
                  ) AS val FROM hr.employees e;

UPDATE emp_sample set val =   
    XMLQuery('copy $tmp := . modify insert node   
              <Comment>Kommentar</Comment> into $tmp/Employee  
              return $tmp'  
              PASSING val   
              RETURNING CONTENT)  
    WHERE empid = 100;

SELECT * FROM emp_sample WHERE empid = 100;

UPDATE emp_sample set val =   
    XMLQuery('copy $tmp := . modify delete node   
              $tmp/Employee/Comment  
              return $tmp'  
              PASSING val   
              RETURNING CONTENT)  
    WHERE empid = 100;

SELECT * FROM emp_sample WHERE empid = 100;

UPDATE emp_sample  set val =   
    XMLQuery('copy $tmp := . modify 
              insert node attribute Unit{$NEU}  
              into $tmp/Employee/Salary 
              return $tmp' 
         PASSING val ,'Euro' AS neu RETURNING CONTENT)  
   WHERE empid = 100;

SELECT * FROM emp_sample WHERE empid = 100;

UPDATE emp_sample  set val =   
    XMLQuery('copy $tmp := . modify 
              delete node $tmp/Employee/Salary/@Unit 
              return $tmp' 
         PASSING val RETURNING CONTENT)  
   WHERE empid = 100;

SELECT * FROM emp_sample WHERE empid = 100;

UPDATE emp_sample  set val =   
    XMLQuery('copy $tmp := . modify 
              insert node  
                <Comment> 
                  <Author> Karrer </Author> 
                  <Date> 10.11.2017 </Date> 
                  <Text> Kommentar </Text>                     
                </Comment> 
              before /Employee/Dept_ID 
              return $tmp' 
         PASSING val RETURNING CONTENT)  
   WHERE empid = 100;

UPDATE emp_sample  set val =   
    XMLQuery('copy $tmp := . modify 
              insert node  
                <Comment> 
                  <Author> Karrer </Author> 
                  <Date> 10.11.2017 </Date> 
                  <Text> Kommentar </Text>                     
                </Comment> 
              before $tmp/Employee/Dept_ID 
              return $tmp' 
         PASSING val RETURNING CONTENT)  
   WHERE empid = 100;

SELECT * FROM emp_sample WHERE empid = 100;

UPDATE emp_sample set val =   
    XMLQuery('copy $tmp := . modify delete node   
              $tmp/Employee/Comment  
              return $tmp'  
              PASSING val   
              RETURNING CONTENT)  
    WHERE empid = 100;

SELECT * FROM emp_sample WHERE empid = 100;

UPDATE emp_sample  set val =   
    XMLQuery('copy $tmp := . modify 
              insert node  
                <Comment> 
                  <Author> Karrer </Author> 
                  <Date> 10.11.2017 </Date> 
                  <Text> Kommentar </Text>                     
                </Comment> 
              after $tmp/Employee/Salary 
              return $tmp' 
         PASSING val RETURNING CONTENT)  
   WHERE empid = 100;

SELECT * FROM emp_sample WHERE empid = 100;

UPDATE emp_sample set val =   
    XMLQuery('copy $tmp := . modify delete node   
              $tmp/Employee/Comment  
              return $tmp'  
              PASSING val   
              RETURNING CONTENT)  
    WHERE empid = 100;

UPDATE emp_sample  set val =   
    XMLQuery('copy $tmp := . modify 
              insert node  
                <Comment> 
                  <Author> Karrer </Author> 
                  <Date> 10.11.2017 </Date> 
                  <Text> Kommentar </Text>                     
                </Comment> 
              as last into $tmp/Employee/Dept_ID 
              return $tmp' 
         PASSING val RETURNING CONTENT)  
   WHERE empid = 100;

SELECT * FROM emp_sample WHERE empid = 100;

UPDATE emp_sample set val =   
    XMLQuery('copy $tmp := . modify delete node   
              $tmp/Employee/Dept_ID/Comment  
              return $tmp'  
              PASSING val   
              RETURNING CONTENT)  
    WHERE empid = 100;

SELECT * FROM emp_sample WHERE empid = 100;

UPDATE emp_sample  set val =   
    XMLQuery('copy $tmp := . modify 
              insert node  
                <Comment> 
                  <Author> Karrer </Author> 
                  <Date> 10.11.2017 </Date> 
                  <Text> Kommentar </Text>                     
                </Comment> 
              as first into $tmp/Employee 
              return $tmp' 
         PASSING val RETURNING CONTENT)  
   WHERE empid = 100;

SELECT * FROM emp_sample WHERE empid = 100;

UPDATE emp_sample set val =   
    XMLQuery('copy $tmp := . modify delete node   
              $tmp/Employee/Comment  
              return $tmp'  
              PASSING val   
              RETURNING CONTENT)  
    WHERE empid = 100;

SELECT * FROM emp_sample WHERE empid = 100;

UPDATE emp_sample  set val =   
    XMLQuery('copy $tmp := . modify 
              rename node $tmp/Employee 
              as Angestellter 
              return $tmp' 
         PASSING val RETURNING CONTENT)  
   WHERE empid = 100;

UPDATE emp_sample  set val =   
    XMLQuery('copy $tmp := . modify 
              rename node $tmp/Employee 
              as $an 
              return $tmp' 
         PASSING val, 'Angestellter' as an RETURNING CONTENT)  
   WHERE empid = 100;

UPDATE emp_sample  set val =   
    XMLQuery('copy $tmp := . modify 
              rename node $tmp/Employee 
              as {$an} 
              return $tmp' 
         PASSING val, 'Angestellter' as an RETURNING CONTENT)  
   WHERE empid = 100;

UPDATE emp_sample  set val =   
    XMLQuery('copy $tmp := . modify 
              rename node $tmp/Employee 
              as "Angestellter" 
              return $tmp' 
         PASSING val, 'Angestellter' as an RETURNING CONTENT)  
   WHERE empid = 100;

SELECT * FROM emp_sample WHERE empid = 100;

UPDATE emp_sample  set val =   
    XMLQuery('copy $tmp := . modify 
              rename node $tmp/Angestellter 
              as "Employee" 
              return $tmp' 
         PASSING val RETURNING CONTENT)  
   WHERE empid = 100;

SELECT * FROM emp_sample WHERE empid = 100;

UPDATE emp_sample  set val =   
    XMLQuery('copy $tmp := . modify 
              replace node $tmp/Employee/Salary 
              with <Comment> 
                    <Author> Karrer </Author> 
                    <Date> 10.11.2017 </Date> 
                    <Text> Kommentar </Text>                     
                   </Comment> 
              return $tmp' 
         PASSING val RETURNING CONTENT)  
   WHERE empid = 100;

SELECT * FROM emp_sample WHERE empid = 100;

UPDATE emp_sample  set val =   
    XMLQuery('copy $tmp := . modify 
              replace node $tmp/Employee/Salary 
              with <Salary> 10000 </Salary> 
              return $tmp' 
         PASSING val RETURNING CONTENT)  
   WHERE empid = 100;

UPDATE emp_sample  set val =   
    XMLQuery('copy $tmp := . modify 
              replace node $tmp/Employee/Comment 
              with <Salary> 10000 </Salary> 
              return $tmp' 
         PASSING val RETURNING CONTENT)  
   WHERE empid = 100;

SELECT * FROM emp_sample WHERE empid = 100;

UPDATE emp_sample set val =   
    XMLQuery('copy $tmp := . modify insert node   
              <Comment>Kommentar</Comment> into $tmp/Employee/*  
              return $tmp'  
              PASSING val   
              RETURNING CONTENT)  
    WHERE empid = 100;

UPDATE emp_sample set val =   
    XMLQuery('copy $tmp := . modify  
              ( for $i in  $tmp/Employee/*  
                return insert node   
                    <Comment>Kommentar</Comment>  
                into $i) 
              return $tmp'  
              PASSING val   
              RETURNING CONTENT)  
    WHERE empid = 100;

SELECT * FROM emp_sample WHERE empid = 100;

UPDATE emp_sample set val =   
    XMLQuery('copy $tmp := . modify delete node   
              $tmp/Employee/*/Comment  
              return $tmp'  
              PASSING val   
              RETURNING CONTENT)  
    WHERE empid = 100;

SELECT * FROM emp_sample WHERE empid = 100;

UPDATE emp_sample set val =   
    XMLQuery('copy $tmp := . modify  
              ( for $i in  $tmp/Employee/*  
                return insert node   
                    <Comment>Kommentar</Comment>  
                into $i) 
              return $tmp'  
              PASSING val   
              RETURNING CONTENT)  
    WHERE empid = 100;

UPDATE emp_sample set val =   
    XMLQuery('copy $tmp := . modify delete node   
              $tmp/Employee/*/Comment  
              return $tmp'  
              PASSING val   
              RETURNING CONTENT)  
    WHERE empid = 100;

UPDATE emp_sample set val =   
    XMLQuery('copy $tmp := . modify  
              ( for $i in  $tmp/Employee/*  
                return replace value of node $i 
                with "Ersetzt" ) 
              return $tmp'  
              PASSING val   
              RETURNING CONTENT)  
    WHERE empid = 100;

SELECT * FROM emp_sample WHERE empid = 100;

