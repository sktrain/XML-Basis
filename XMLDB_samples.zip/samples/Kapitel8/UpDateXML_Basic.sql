-- aus Sicht von SQL
CREATE TABLE XML_TABLE OF XMLTYPE;

INSERT INTO XML_TABLE VALUES 
     (XMLType('<Termin Nr="498">
                  <Beginn>10.06.03</Beginn>
                  <Ende>13.06.03</Ende>
                </Termin>'));
                
UPDATE XML_TABLE SET OBJECT_VALUE = 
        XMLType('<Termin Nr="498">
                  <Beginn>07.08.17</Beginn>
                  <Ende>09.08.17</Ende>
                 </Termin>') where rownum = 1;
                 
-- aus Sicht von XML
SELECT UPDATEXML( 
     XMLType('<Termin Nr="498">  
                <Beginn>10.06.03</Beginn>
                <Ende>13.06.03</Ende>
               </Termin>'),  -- XML-Instanz
              'Termin/@Nr',  -- Adressierung 
              '555')    -- neuer Wert
  as "Result"      FROM dual;
                  