SELECT XMLELEMENT("Employee", 
                  XMLATTRIBUTES( e.employee_id as "id"),
                  XMLFOREST (e.last_name as "Name",
                             e.salary as "Salary",
                             e.department_id as "Dept_ID")
                  ) AS "Result" FROM employees e;
                  
/*
<Employee id="100">
  <Name>K�nig</Name>
  <Salary>100663,3</Salary>
  <Dept_ID>90</Dept_ID>
</Employee>

bzw. falls department_id = null:

<Employee id="4912">
  <Name>Mustermann</Name>
  <Salary>5000</Salary>
</Employee>
*/

DROP TABLE emp_sample;
CREATE TABLE emp_sample AS 
  SELECT employee_id as empid,
         XMLELEMENT("Employee", 
                  XMLATTRIBUTES( e.employee_id as "id"),
                  XMLFOREST (e.last_name as "Name",
                             e.salary as "Salary",
                             e.department_id as "Dept_ID")
                  ) AS val FROM employees e;
                  
SELECT * FROM emp_sample;

-- einfaches InsertChild
UPDATE emp_sample e set e.val =  
    INSERTCHILDXML(e.val,   
    '/Employee', 
    'Comment',   
    XMLType('<Comment>Kommentar</Comment>')) 
WHERE empid =100;

UPDATE emp_sample e set e.val =  
    DELETEXML(e.val,   
    '/Employee/Comment')
WHERE empid =100;

-- InsertChildXML, allerdings Mixed Content als Ergebnis
UPDATE emp_sample e set e.val =  
    INSERTCHILDXML(e.val,   
    '/Employee/Salary', 
    'Unit',   
    XMLType('<Unit>Euro</Unit>')) 
WHERE empid =100;

UPDATE emp_sample e set e.val =  
    DELETEXML(e.val,   
    '/Employee/Salary/Unit')
WHERE empid =100;

select * from emp_sample where empid = 100;

-- besser einf�gen als Attribut, hier zu Employee
UPDATE emp_sample e set e.val =  
    INSERTCHILDXML(e.val,   
    '/Employee', '@Unit', 'Euro') 
WHERE empid =100;

UPDATE emp_sample e set e.val =  
    DELETEXML(e.val,   
    '/Employee/@Unit')
WHERE empid =100;

-- Einf�gen als Attribut zu Salary 
UPDATE emp_sample e set e.val =  
    INSERTCHILDXML(e.val,   
    '/Employee/Salary', '@Unit', 'Euro') 
WHERE empid =100;

UPDATE emp_sample e set e.val =  
    DELETEXML(e.val,   
    '/Employee/Salary/@Unit')
WHERE empid =100;

-- mal was komplexeres einf�gen: Subquery-Ergebnis f�r Dep.-Daten
SELECT XMLELEMENT("Department", 
                   XMLFOREST (d.department_name as "Name",
                              d.manager_id as "Man_Id",
                              d.location_id as "Loc_Id")
                  ) AS val FROM hr.departments d
    WHERE d.department_id = (SELECT department_id from hr.employees where employee_id = 100);
    
UPDATE emp_sample e set e.val =  
    INSERTCHILDXML(e.val,   
    '/Employee', 
    'Department',   
    (SELECT XMLELEMENT("Department", 
                   XMLFOREST (d.department_name as "Name",
                              d.manager_id as "Man_Id",
                              d.location_id as "Loc_Id")
                  ) FROM hr.departments d
    WHERE d.department_id = 
    (SELECT department_id from hr.employees where employee_id = 100))) 
WHERE empid =100;


/* 
 *  InsertXMLBefore
 */
 
UPDATE emp_sample set val =  
    INSERTXMLBEFORE(val,   
                    '/Employee/Dept_ID', 
                    XMLType('<Comment>
                               <Author> Karrer </Author>
                               <Date> 10.11.2017 </Date>
                               <Text> Kommentar </Text>                    
                             </Comment>')) 
WHERE empid =100;

UPDATE emp_sample e set e.val =  
    DELETEXML(e.val,   
    '/Employee/Comment')
WHERE empid =100;

select * from emp_sample where empid = 100;

/*
 * InsertXMLAfter
 */
UPDATE emp_sample set val =  
    INSERTXMLAFTER(val,   
                    '/Employee/Salary', 
                    XMLType('<Comment>
                               <Author> Karrer </Author>
                               <Date> 10.11.2017 </Date>
                               <Text> Kommentar </Text>                    
                             </Comment>')) 
WHERE empid =100;

UPDATE emp_sample e set e.val =  
    DELETEXML(e.val,   
    '/Employee/Comment')
WHERE empid =100;

select * from emp_sample where empid = 100;

/*
 * AppendChildXML
 */
UPDATE emp_sample set val =  
    AppendChildXML(val,   
                    '/Employee/Dept_ID', 
                    XMLType('<Comment>
                               <Author> Karrer </Author>
                               <Date> 10.11.2017 </Date>
                               <Text> Kommentar </Text>                   
                             </Comment>')) 
WHERE empid =100;

UPDATE emp_sample e set e.val =  
    DELETEXML(e.val,   
    '/Employee/Dept_ID/Comment')
WHERE empid =100;

select * from emp_sample where empid = 100;

/*
 * InsertChildXMLBefore
 */
UPDATE emp_sample set val =  
    InsertChildXMLBefore(val,
                    '/Employee',
                    'Dept_ID', 
                    XMLType('<Comment>
                               <Author> Karrer </Author>
                               <Date> 10.11.2017 </Date>
                               <Text> Kommentar </Text>                   
                             </Comment>')) 
WHERE empid =100;

UPDATE emp_sample e set e.val =  
    DELETEXML(e.val,   
    '/Employee/Comment')
WHERE empid =100;

select * from emp_sample where empid = 100;




UPDATE po_sample p SET val =
   INSERTXMLBEFORE(val,     
                   '/PurchaseOrder/Actions',
                   XMLType('<name>Stephan Karrer</name>'))
 WHERE id LIKE '%5771%'; 
 
UPDATE warehouses SET warehouse_spec =
insertXMLbefore(
warehouse_spec,
'/Warehouse/RailAccess',
XMLType('<SkyAccess>N</SkyAccess>');
