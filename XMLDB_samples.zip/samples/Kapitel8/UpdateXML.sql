/* XML-Update */

-- um folgenden Wert geht es
SELECT XMLQuery('$p/PurchaseOrder/User' 
                 PASSING OBJECT_VALUE AS "p" 
                 RETURNING CONTENT) 
   as "Result" FROM purchaseorder
    WHERE XMLExists(
    '$p/PurchaseOrder[Reference="SBELL-2002100912333601PDT"]' 
     PASSING OBJECT_VALUE AS "p");
     
-- wir wollen 'SBELL' gegen 'SKING' ersetzen via UpdateXML
UPDATE purchaseorder SET OBJECT_VALUE =
  updateXML(OBJECT_VALUE, 
            '/PurchaseOrder/User/text()', 
            'SKING')
 WHERE XMLExists(
 '$p/PurchaseOrder[Reference="SBELL-2002100912333601PDT"]'
    PASSING OBJECT_VALUE AS "p");
    
-- erneute Abfrage zur Pr�fung
SELECT XMLQuery('$p/PurchaseOrder/User' 
                 PASSING OBJECT_VALUE AS "p" 
                 RETURNING CONTENT) 
   as "Result" FROM purchaseorder
    WHERE XMLExists(
    '$p/PurchaseOrder[Reference="SBELL-2002100912333601PDT"]' 
     PASSING OBJECT_VALUE AS "p");
     
-- alternativ mit XQuery-Update-Facility 
UPDATE purchaseorder SET OBJECT_VALUE =
  XMLQuery('copy $i := $p1 modify
           (for $j in $i/PurchaseOrder/User
            return replace value of node $j with $p2)
            return $i'
    PASSING OBJECT_VALUE AS "p1", 
            'SKING' AS "p2" RETURNING CONTENT)
WHERE XMLExists(
  '$p/PurchaseOrder[Reference="SBELL-2002100912333601PDT"]'
    PASSING OBJECT_VALUE AS "p");
    
