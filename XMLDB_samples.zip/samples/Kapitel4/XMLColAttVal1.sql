SELECT XMLElement("Employee",
      XMLAttributes(e.last_name AS "fullname" ),
      XMLColAttVal(e.salary, e.department_id AS "department"))
AS "RESULT"
FROM hr.employees e
WHERE e.department_id = 50;