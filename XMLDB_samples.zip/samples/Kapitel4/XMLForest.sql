-- XMLForest
SELECT XMLElement("Emp", XMLAttributes(e.first_name
  ||' '
  || e.last_name AS "name"), XMLForest(e.hire_date, e.department_id AS "department")) AS "RESULT"
FROM employees e
WHERE e.department_id = 20;

     
SELECT XMLELEMENT("Employee", 
                  XMLATTRIBUTES( e.employee_id as "id"),
                  XMLFOREST (e.last_name as "Name",
                             e.salary as "Salary",
                             e.department_id as "Dept_ID"),
                  XMLELEMENT("Department",
                    XMLFOREST(d.department_name as "Name",
                              d.manager_id as "Manager",
                              d.location_id as "Location")))
    as "Result" FROM employees e JOIN departments d
      ON e.department_id = d.department_id
      WHERE e.employee_id = 110;
      
-- das w�re nicht wohlgeformt
SELECT XMLELEMENT("Employee", 
                  XMLATTRIBUTES( e.employee_id as "id"),
                  XMLFOREST (e.last_name as "Name",
                             e.salary as "Salary",
                             e.department_id as "Dept_ID")),
                  XMLELEMENT("Department",
                    XMLFOREST(d.department_name as "Name",
                              d.manager_id as "Manager",
                              d.location_id as "Location"))
    as "Result" FROM employees e JOIN departments d
      ON e.department_id = d.department_id
      WHERE e.employee_id = 110;