SELECT SYS_XMLGEN(last_name), SYS_XMLGEN(salary)
    FROM employees;
    
/*
STATIC FUNCTION createFormat(
enclTag IN varchar2 := 'ROWSET',
schemaType IN varchar2 := 'NO_SCHEMA',
schemaName IN varchar2 := null,
targetNameSpace IN varchar2 := null,
dburlPrefix IN varchar2 := null,
processingIns IN varchar2 := null) RETURN XMLGenFormatType
deterministic parallel_enable
*/

SELECT SYS_XMLGEN(last_name, 
    XMLFORMAT.createFormat(enclTag => 'Lname'))
    FROM employees;

-- SYS_XMLGEN  mit Objekt-Typ
CREATE OR REPLACE TYPE addr_typ AS OBJECT
( city VARCHAR2(20), street VARCHAR2(50) );
  
CREATE OR REPLACE TYPE person_typ AS OBJECT
(pno NUMBER(6), pname VARCHAR2(25),
 addr  addr_typ);
 
SELECT SYS_XMLGEN (
  person_typ( 100,
              'Karrer',
              addr_typ( 'Fulda',
                        'Steinstr.'
         ))) AS "Result" FROM DUAL;
              
    
-- mit Schema: Schema muss registriert sein und der Inhalt als 
-- Wurzelelement definiert sein
-- funktioniert aber erstmal nicht f�r den folgenden Fall
Begin
DBMS_XMLSCHEMA.REGISTERSCHEMA(
   'http://karrer/lname.xsd',
   '<xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema" elementFormDefault="qualified" >
     <xs:element name="LAST_NAME" type="xs:string" />
</xs:schema>
');
end;


SELECT SYS_XMLGEN(last_name,  
    XMLFORMAT.createFormat(enclTag => 'LAST_NAME',
                           schematype => 'USE_GIVEN_SCHEMA',
                           schemaname => 'http://karrer/lname.xsd'))
    FROM employees;
    