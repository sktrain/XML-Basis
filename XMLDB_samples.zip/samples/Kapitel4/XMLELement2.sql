-- With standard XML date format:
SELECT XMLElement("Date", hire_date)
FROM hr.employees
WHERE employee_id = 203;
-- With an alternative date format:
SELECT XMLElement("Date", TO_CHAR(hire_date))
FROM hr.employees
WHERE employee_id = 203;


CREATE OR REPLACE TYPE emp_t
AS
  OBJECT
  (
    "@EMPNO" NUMBER(4),
    ENAME    VARCHAR2(10));

CREATE OR REPLACE TYPE emplist_t
AS
  TABLE OF emp_t;
  
CREATE OR REPLACE TYPE dept_t
AS
  OBJECT
  (
    "@DEPTNO" NUMBER(2),
    DNAME     VARCHAR2(14),
    EMP_LIST emplist_t);
    
SELECT XMLElement("Department",
    dept_t(department_id, department_name, CAST(MULTISET
    (SELECT employee_id,
      last_name
    FROM hr.employees e
    WHERE e.department_id = d.department_id
    ) AS emplist_t)))
    AS deptxml
  FROM hr.departments d
  WHERE d.department_id = 10;