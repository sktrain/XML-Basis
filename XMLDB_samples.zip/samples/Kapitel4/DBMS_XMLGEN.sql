DROP TABLE temp_clob_tab;

CREATE TABLE SAMPLE_XML(Result clob);

DECLARE
  myctx DBMS_XMLGEN.ctxHandle;
  res CLOB;
BEGIN
  myctx := DBMS_XMLGEN.newContext('SELECT * FROM hr.departments');
  DBMS_XMLGEN.setMaxRows(myctx, 5);
  LOOP
    res := DBMS_XMLGEN.getXML(myctx);
    EXIT WHEN DBMS_XMLGEN.getNumRowsProcessed(myctx) = 0;
    INSERT INTO SAMPLE_XML VALUES(res);
  END LOOP;
  DBMS_XMLGEN.closeContext(myctx);
END;

SELECT * FROM temp_clob_tab;

CREATE TABLE new_tab(x XMLType);
DECLARE
qryctx DBMS_XMLGEN.ctxhandle;
result CLOB;
BEGIN
qryctx := DBMS_XMLGEN.newcontextFromHierarchy(
'SELECT level,
XMLElement("NAME", last_name) AS myname FROM hr.employees
CONNECT BY PRIOR employee_id=manager_id
START WITH employee_id = 102');
DBMS_XMLGEN.setRowSetTag(qryctx, 'mynum_hierarchy');
result:=DBMS_XMLGEN.getxml(qryctx);
INSERT INTO new_tab VALUES(XMLType(result));
COMMIT;
DBMS_XMLGEN.closecontext(qryctx);
END;
select * from new_tab;