SELECT XMLConcat(
    XMLType('<PartNo>1010</PartNo>'),
    XMLType('<PartName>Teil1</PartName>'),
    XMLType('<PartPrice>20.60</PartPrice>'))
AS "RESULT"
FROM DUAL;

SELECT XMLSerialize(
CONTENT
XMLConcat (XMLType('<PartNo>1236</PartNo>'),
XMLType('<PartName>Widget</PartName>'),
XMLType('<PartPrice>29.99</PartPrice>'))
AS CLOB)
AS "RESULT"
FROM DUAL;

SELECT XMLConcat(XMLSequenceType(
XMLType('<PartNo>1236</PartNo>'),
XMLType('<PartName>Widget</PartName>'),
XMLType('<PartPrice>29.99</PartPrice>')))

AS "RESULT"
FROM DUAL;


SELECT XMLSerialize(
CONTENT
XMLConcat(XMLSequenceType(
XMLType('<PartNo>1236</PartNo>'),
XMLType('<PartName>Widget</PartName>'),
XMLType('<PartPrice>29.99</PartPrice>')))
AS CLOB)
AS "RESULT"
FROM DUAL;