-- Bsp. aus Doku

SELECT XMLElement("Emp",
                  XMLAttributes(e.first_name ||' '||e.last_name AS "fullname" ),
                  XMLColAttVal(e.hire_date, e.department_id AS "department"))
          AS "RESULT"
FROM hr.employees e
WHERE e.department_id = 30;