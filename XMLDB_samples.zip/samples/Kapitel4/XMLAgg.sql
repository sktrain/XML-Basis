show all
show linesize

-- bsp aus der doku  
SELECT XMLElement("Department", XMLAgg(XMLElement("Employee",
e.job_id||' '||e.last_name)
ORDER BY e.last_name))
AS "Dept_list"
FROM hr.employees e
WHERE e.department_id = 30 OR e.department_id = 40;

SELECT XMLElement("Department", XMLAttributes(department_id AS "deptno"),
XMLAgg(XMLElement("Employee", e.job_id||' '||e.last_name)))
AS "Dept_list"
FROM hr.employees e
GROUP BY e.department_id;

-- XMLAGG Motivation: department_name taucht mehrfach auf
SELECT d.department_name, e.first_name, e.last_name
FROM departments d JOIN employees e
  ON d.department_id = e.department_id;

-- somit bei einfacher XML-Generierung: mixed content
SELECT XMLELEMENT(department_name,    -- hier ist kein Tab.-Alias erlaubt!!
                  XMLELEMENT(first_name, first_name), 
                  XMLELEMENT(last_name, last_name), 
                  DEPARTMENT_NAME) as result
FROM departments d JOIN employees e
  ON d.department_id = e.department_id;

-- oder department_name als Attribut
SELECT XMLELEMENT(department,
                  XMLATTRIBUTES(d.department_name),
                  XMLELEMENT(first_name, e.first_name), 
                  XMLELEMENT(last_name, e.last_name) 
                  ) as result
FROM departments d JOIN employees e
  ON d.department_id = e.department_id;

-- oder alles als Kindelement
SELECT XMLELEMENT(department,
                  XMLELEMENT(department_name, d.department_name),
                  XMLELEMENT(first_name, e.first_name), 
                  XMLELEMENT(last_name, e.last_name) 
                  ) as result
FROM departments d JOIN employees e
  ON d.department_id = e.department_id;

-- jetzt mit XMLAGG, damit sich die Abteilungsnamen nicht zigfach wiederholen
-- XMLAGG ist Aggregatsfunktion, d.h. GROUP BY ist hier notwendig
SELECT XMLELEMENT(department_name, 
                  XMLATTRIBUTES(d.department_name),
                  XMLAGG(XMLELEMENT(last_name, e.last_name)
                  ))   as result
FROM departments d JOIN employees e
  ON d.department_id = e.department_id
GROUP by d.department_name;

-- mit Hilfe von XMLConcat kann man mehrere XML-Elemente je Treffer in der
-- Gruppe ausgeben
SELECT XMLELEMENT(department_name, 
                  XMLATTRIBUTES(d.department_name),
                  XMLAGG(XMLCONCAT (XMLELEMENT(first_name, e.first_name)
                         , XMLELEMENT(last_name, e.last_name))
                  ))   as result
FROM departments d JOIN employees e
  ON d.department_id = e.department_id
GROUP by d.department_name;

-- XMLAGG kann auch mit  Subqueries verwendet werden
-- allerdings ist in der subquery nur eine Value-Spalte m�glich 
SELECT XMLELEMENT(departments,
                 XMLElement(department_name, 
                            XMLATTRIBUTES(d.department_name),
                            (SELECT XMLAGG(XMLFOREST(first_name, last_name)) 
                                  --XMLAGG(XMLELEMENT(last_name, e.last_name))
                                   FROM employees e
                                   WHERE e.department_id = d.department_id
                             ) )
                  )as result
FROM departments d;

