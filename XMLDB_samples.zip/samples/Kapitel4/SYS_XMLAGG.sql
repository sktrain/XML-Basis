-- aus der Doku
SELECT SYS_XMLAGG(SYS_XMLGEN(last_name)) XMLAGG
  FROM employees
  WHERE last_name LIKE 'R%'
  ORDER BY xmlagg;
  
SELECT SYS_XMLAGG( XMLCONCAT(
                      XMLELEMENT(last_name, e.last_name), 
                      XMLELEMENT(first_name, e.first_name)))
    AS "Result"
 FROM employees e;