SELECT XMLELEMENT("Emp", XMLELEMENT("Name",
e.job_id||' '||e.last_name),
XMLELEMENT(hire_date, e.hire_date)) as "Result"
FROM employees e WHERE employee_id > 200;

SELECT XMLELEMENT(Emp, XMLELEMENT("Name",
e.job_id||' '||e.last_name),
XMLELEMENT("Hiredate", e.hire_date)) as "Result"
FROM employees e WHERE employee_id > 200;

SELECT XMLELEMENT (Name buch, XMLAttributes('Hanser' as "Verlag", 2002 as Jahr), 'Test') from dual;

CREATE TABLE emp AS SELECT LAST_NAME as "last:name" FROM employees;

insert into emp values ('xxxxx>yyyyy');

select XMLELEMENT("last:name", "last:name") from emp;