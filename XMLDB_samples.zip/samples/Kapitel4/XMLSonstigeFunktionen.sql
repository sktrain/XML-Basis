SELECT XMLPI(NAME "MyInstruction", 'nothing to do')
   AS pi FROM DUAL;
   
SELECT XMLELEMENT("Item", 'Test',
    XMLComment('This is a comment')) AS cmnt FROM DUAL;

SELECT XMLRoot(XMLType('<Item>Test</Item>'), 
      VERSION '1.0', STANDALONE YES) AS xmlroot FROM DUAL;
